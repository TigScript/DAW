// Bucle for
let tablaDe7 = document.getElementById('tablaDe7');
for (let i = 1; i <= 10; i++) {
  let resultado = 7 * i;
  let listItem = document.createElement('li');
  listItem.textContent = `7 x ${i} = ${resultado}`;
  tablaDe7.appendChild(listItem);
}

// Bucle While
let tablaSumar8 = document.getElementById('tablaSumar8');
let j = 1;
while (j <= 10) {
  let resultadoSuma = 8 + j;
  let listItemSuma = document.createElement('li');
  listItemSuma.textContent = `8 + ${j} = ${resultadoSuma}`;
  tablaSumar8.appendChild(listItemSuma);
  j++;
}

// Tabla de dividir de 9 usando bucle do-while, uso los nombres de variables i,j,k porque son los más comunes a la hora de declarar
let tablaDividir9 = document.getElementById('tablaDividir9');
let k = 1;
do {
  let resultadoDivision = 9 / k;
  let listItemDivision = document.createElement('li');
  listItemDivision.textContent = `9 / ${k} = ${resultadoDivision}`;
  tablaDividir9.appendChild(listItemDivision);
  k++;
} while (k <= 10);

// 125 / 8 usando desplazamiento a la derecha de bits
let resultadoDivision1 = 125 >> 3;
document.getElementById('resultadoDivision1').textContent = "125 / 8 = " + resultadoDivision1;

// 40 x 4 usando desplazamiento a la izquierda de bits
let resultadoMultiplicacion1 = 40 << 2;
document.getElementById('resultadoMultiplicacion1').textContent = "40 x 4 = " + resultadoMultiplicacion1;

// 25 / 2 usando desplazamiento a la derecha de bits, no consigo que me de los decimales aun haciendo un parse float a resultadoDivision2...
let resultadoDivision2 = 25 >> 1;
document.getElementById('resultadoDivision2').textContent = "25 / 2 = " + resultadoDivision2;

// 10 x 16 usando desplazamiento a la izquierda de bits
let resultadoMultiplicacion2 = 10 << 4;
document.getElementById('resultadoMultiplicacion2').textContent = "10 x 16 = " + resultadoMultiplicacion2;
