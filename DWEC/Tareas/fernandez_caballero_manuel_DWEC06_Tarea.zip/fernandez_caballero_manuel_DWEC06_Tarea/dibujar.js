


// Función para obtener un elemento por su ID y abreviar el código evitando escribir document.getElementById("elemento") todo el rato...
function getId(elemento) {
	return document.getElementById(elemento);
}


// Declaramos la variable crearEvento y para manejar si un navegador antiguo no admite addEventListener, cosa que a día de hoy no creo que sea muy útil pero es una buena práctica
var crearEvento = function () {
	// Función navegadorNuevo para navegadores modernos que admiten addEventListener.
	function navegadorNuevo(elemento, evento, mifuncion) {
		elemento.addEventListener(evento, mifuncion, false);
	}

	// Función navegadorViejo para navegadores antiguos que admiten attachEvent.
	function navegadorViejo(elemento, evento, mifuncion) {
		var fx = function () {
			mifuncion.call(elemento);
		};

		elemento.attachEvent('on' + evento, fx);
	}

	// Comprobamos si el navegador admite addEventListener...
	if (typeof window.addEventListener !== 'undefined') { //verifico si la propiedad addEventListener en el objeto window no es undefined, si es así
		// Si es así, devolvemos la función navegadorNuevo.
		return navegadorNuevo;

		// se asume que el navegador no es compatible con addEventListener y se verifica si es compatible con attachEvent
		//si no se cumple el if anterior, se asume que el navegador no es compatible con addEventListener y se verifica si es compatible con attachEvent
	} else if (typeof window.attachEvent !== 'undefined') {
		// Si no, devolvemos la función navegadorViejo.
		return navegadorViejo;
	}
}();


// función para dibujar el tablero de dibujo 
function dibujarTableroDibujo() {
	//creamos el elemento tabla, y añadimos el borde, id y clase como atributos
	var crearTabla = document.createElement("table");
	crearTabla.setAttribute("border", "1");
	crearTabla.setAttribute("id", "tablero");
	crearTabla.setAttribute("class", "tablerodibujo");
	//titulo para la tabla
	var tituloTabla = document.createElement("caption");
	var contenidoTitulo = document.createTextNode("Haga CLICK en cualquier celda para activar/desactivar el Pincel");
	tituloTabla.appendChild(contenidoTitulo);
	crearTabla.appendChild(tituloTabla);


	// Creamos las filas de la tabla y las celdas dentro de cada fila.
	//"Para ello tendrás que dibujar una tablero de 30 celdas x 30 celdas con cada celda de ancho 10 px y alto 10 px.
	//Utilizo un bucle for hasta el 30 para crear una fila y otro for dentro de este para añadir un hijo como celda de cada fila
	for (var i = 1; i <= 30; i++) {
		var nuevaFila = document.createElement("tr");
		for (var j = 1; j <= 30; j++) {
			var nuevaCelda = document.createElement("td");
			nuevaFila.appendChild(nuevaCelda);
		}
		crearTabla.appendChild(nuevaFila);
	}
	// Insertamos la tabla dentro del DIV zonadibujo. "Una vez generado el tablero lo meterás dentro del div con id "zonadibujo"."
	getId("zonadibujo").appendChild(crearTabla);
}




// Haremos click en alguno de los 5 colores de la paleta y se le asignará la clase "seleccionado", de default seleccionaremos el primer color de la paleta
// Función para detectar el color de la paleta de colores
function detectarColorPaleta() {
	// Iteramos sobre los nodos secundarios del nodo padre
	for (var i = 0; i < this.parentNode.childNodes.length; i++) {
		var nodo = this.parentNode.childNodes[i];

		// Verificamos si el nodo es un elemento (ignorando nodos de texto)
		if (nodo.nodeType === 1) {
			// verifico si el agente de usuario contiene "MSIE" o "Trident", que son indicativos de Internet Explorer...
			if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) {

				// Quitamos la clase 'seleccionado' del nodo.
				nodo.className = nodo.className.replace(/\bseleccionado\b/, '');
			} else {
				// En otros navegadores, eliminamos la clase 'seleccionado'.
				nodo.classList.remove("seleccionado");
			}
		}
	}

	// Seleccionamos el color activo basándonos en la compatibilidad del navegador.
	if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) {
		// verifico si el agente de usuario contiene "MSIE" o "Trident", que son indicativos de Internet Explorer...
		colorSeleccionado = this.className;
		// Añadimos la clase 'seleccionado' al nodo actual.
		this.className += " seleccionado";
	} else {
		colorSeleccionado = this.classList[0];
		// Añadimos la clase 'seleccionado' al nodo actual.
		this.classList.add("seleccionado");
	}
}




// Función principal que inicia el tablero de dibujo y asigna los eventos correspondientes...
function iniciar() {
	// Dibujamos la tabla donde pintaremos con el ratón
	dibujarTableroDibujo();
	// A la tabla de colores le asignamos el evento de click para seleccionar un color.
	var tablaColores = getId("paleta");

	var celdasColores = tablaColores.getElementsByTagName("td");
	for (var i = 0; i < celdasColores.length - 1; i++) { //celdasColores.length - 1 para no seleccionar la celda del titulo también
		crearEvento(celdasColores[i], "click", detectarColorPaleta);
	}
	// Ponemos como color activo de pintura el color de la primera celda
	// Si estamos usando Internet Explorer
	if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) {
		// Usaremos className en lugar de classList
		colorSeleccionado = celdasColores[0].className.split(" ")[0];
	} else
		colorSeleccionado = celdasColores[0].classList[0];
	// Al tablero de dibujo le asignamos el evento de click para activar o desactivar la pintura
	var tablero = getId("tablero");
	var celdasTablero = tablero.getElementsByTagName("td");


	//asigno el evento de seleccionar el color
	for (var i = 0; i < celdasTablero.length; i++) {
		crearEvento(celdasTablero[i], "click", seleccionarColor);
	}

	//asigno el evento de pintar con mouseover al tablero

	tablero = getId("tablero");
	celdasTablero = tablero.getElementsByTagName("td");
	for (var i = 0; i < celdasTablero.length; i++) {
		crearEvento(celdasTablero[i], "mouseover", pintar);
	}
}






// Función para activar o desactivar la pintura al hacer clic en el pincel.
function seleccionarColor(evt) {
	// Verificamos si podemos pintar nada mas cargar la pagina,  que de default estará desactivado, es decir, en false
	if (pintarTablero) { 
		// Desactivamos el pincel y actualizamos el mensaje.
		getId("pincel").childNodes[0].nodeValue = "PINCEL DESACTIVADO...";
		pintarTablero = false;
	} else {
		// Activamos el pincel y actualizamos el mensaje.
		getId("pincel").childNodes[0].nodeValue = "PINCEL ACTIVADO...";
		pintarTablero = true;

		// Si estamos utilizando Internet Explorer, aplicamos el color activo como clase.
		if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) 
			this.className = colorSeleccionado;
		else
			// En otros navegadores, añadimos la clase correspondiente al color activo.
			this.classList.add(colorSeleccionado);
	}
}

// Función para pintar sobre el tablero.
function pintar(evt) {
	// Verificamos si la pintura está activada.,,,
	if (pintarTablero) {
		// Si estamos utilizando Internet Explorer, aplicamos el color activo como clase.
		if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) {
			this.className = colorSeleccionado;
		} else {
			// En otros navegadores, eliminamos las clases previas y aplicamos el color activo.
			for (var i = 0; i < this.classList.length; i++) {
				this.classList.remove(this.classList[i]);
			}

			this.classList.add(colorSeleccionado);
		}
	}
}

// Variables globales de la aplicación
var colorSeleccionado = "";
var pintarTablero = false;
// Al cargar el documento, se llama a la función 'iniciar', es una buena práctica cargar los scripts al final dpara mejorar el rendimiento 
// y garantizar que todos los elementos y scripts estén disponibles, he probado la tarea con Microsoft Edge, Internet Explorer y Google Chrome aunque no ha sido necesario ya
// que la función attachEvent es específica de Internet Explorer(anterior a IE9) ...
crearEvento(window, "load", iniciar);
