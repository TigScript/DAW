//funcion para instanciar objeto edificio
function edificio(calle, numero, codigo, plantas) {
    // Propiedades
    this.calle = calle;
    this.numero = numero;
    this.codigo = codigo;
    this.plantas = plantas; // dentro de cada planta tendremos un número de puertas y para cada puerta almacenaremos el nombre del propietario
    this.informacion = [];

    // Se le pasa el número de plantas que queremos crear en el piso y el número de puertas por planta. Cada vez que se llame a este método, 
    // añadirá el número de plantas y puertas indicadas en los parámetros, a las que ya están creadas en el edificio.
    this.agregarPlantasYPuertas = function (numplantas, puertas) {
        this.plantas += numplantas; //añado plantas y puertas a las ya creadas en el edificio
        this.puertas += puertas;

        imprimir('<br> Agrego ' + numplantas + ' plantas y ' + puertas + ' puertas (' + numplantas + ',' + puertas + ')');


        // bucle recorrer plantas
        var num = 0;
        for (var i = 1; i <= numplantas; i++) {
            // bucle puertas por planta
            for (var p = 1; p <= puertas; p++) {
                
imprimir('<li>Añado plantas y puertas: nombre: - planta: ' + i + ' - puerta: ' + p + '</li>');


                num++;
            }
        }



    };

    this.modificarNumero = function (numero) { // Se le pasa el nuevo número del edificio para que lo actualice.
        this.numero = numero;
    };

    this.modificarCalle = function (calle) { //Se le pasa el nuevo nombre de la calle para que lo actualice.
    };

    this.modificarCodigoPostal = function (codigo) { //Se le pasa el nuevo número de código postal del edificio.
        this.codigo = codigo;
    };

    this.imprimeCalle = this.calle;
    this.imprimeNumero = this.numero;
    this.imprimeCodigoPostal = this.codigo; 
    // this.imprimeCalle = function () {
    //     return this.calle;
    // };

    // this.imprimeNumero = function () {
    //     return this.numero;
    // };

    // this.imprimeCodigoPostal = function () {
    //     return this.codigo;
    // };

    this.agregarPropietario = function (nombre, planta, puerta) {
        // Se agrega un nuevo propietario al array informacion
        this.informacion.push({
            nombre: nombre,
            planta: planta,
            puerta: puerta
        });
        //cuando agregamos un propietario mostrmaos la información 
        imprimir('<br>' + nombre + ' es ahora el propietario de la puerta ' + puerta + ' de la planta ' + planta);



    };

    this.imprimePlantas = function () {
        imprimir("<br>Listado de propietarios del edificio calle " + this.imprimeCalle + " número " + this.imprimeNumero);
        // Recorre el edificio e imprimirá todos los propietarios de cada puerta
        for (var i = 0; i < this.informacion.length; i++) {
            imprimir('<br> - Propietario del piso ' + this.informacion[i]['puerta'] + ' de la planta ' + this.informacion[i]['planta'] + ': ' + this.informacion[i]['nombre']);
        }
    };

    imprimir('<br>Construido nuevo edificio en calle: ' + this.calle + ', nº: ' + this.numero + ', CP: ' + this.codigo);

}
//funcion imprimir para escribir directamente en el html
function imprimir(texto) {
    document.write(texto);
}
// Instanciamos 3 objetos edificioA, edificioB y edificioC con estos datos:
// •	Construido nuevo edificio en calle: Garcia Prieto, nº: 58, CP: 15706.
// •	Construido nuevo edificio en calle: Camino Caneiro, nº: 29, CP: 32004.
// •	Construido nuevo edificio en calle: San Clemente, nº: s/n, CP: 15705.
imprimir('<br><span style="font-size: 18px; font-weight: bold;">Trabajando con objetos Javascript:</span><br>');


var edificioA = new edificio('Garcia Prieto', '58', '15706', '0');
var edificioB = new edificio('Camino Caneiro', '29', '32004', '0');
var edificioC = new edificio('San Clemente', 's/n', '15705', '0');

// •	El código postal del edificio A es: 15706.
// •	La calle del edificio C es: San Clemente.
// •	El edificio B está situado en la calle Camino Caneiro número 29.
// Separo los apartados con saltos de linea para que se vean mejor

imprimir('<br><br>El código postal del edificio A es: ' + edificioA.imprimeCodigoPostal);
imprimir('<br>La calle del edificio C es: ' + edificioC.imprimeCalle);
imprimir('<br>El edificio B está situado en la calle ' + edificioB.imprimeCodigoPostal + ' número ' + edificioB.imprimeNumero);
imprimir('<br>');
// Agregamos 2 plantas y 3 puertas por planta al edificio A...

edificioA.agregarPlantasYPuertas(2, 3);
imprimir('<br>');
// Agregamos 4 propietarios al edificio A...
// •	Jose Antonio Lopez es ahora el propietario de la puerta 1 de la planta 1.
// •	Luisa Martinez es ahora el propietario de la puerta 2 de la planta 1.
// •	Marta Castellón es ahora el propietario de la puerta 3 de la planta 1.
// •	Antonio Pereira es ahora el propietario de la puerta 2 de la planta 2.
edificioA.agregarPropietario('Jose Antonio Lopez', '1', '1');
edificioA.agregarPropietario('Luisa Martinez', '1', '2');
edificioA.agregarPropietario('Marta Castellón', '1', '3');
edificioA.agregarPropietario('Antonio Pereira', '2', '2');
imprimir('<br>');
edificioA.imprimePlantas();
//output: Listado de propietarios del edificio calle Garcia Prieto número 58
// - Propietario del piso 1 de la planta 1: Jose Antonio Lopez
// - Propietario del piso 2 de la planta 1: Luisa Martinez
// - Propietario del piso 3 de la planta 1: Marta Castellón
// - Propietario del piso 2 de la planta 2: Antonio Pereira

imprimir('<br>');
// Agregamos 1 planta más al edificio A...,me imagino que de tres puertas
edificioA.agregarPlantasYPuertas("1", "3");
imprimir('<br>');
// Agregamos 1 propietario más al edificio A planta 3, puerta 2...
edificioA.agregarPropietario('Pedro Meijide', '3', '2');
imprimir('<br>');
edificioA.imprimePlantas();

// Desearía recibir la corrección del ejercicio de la forma más eficiente para prepararme de cara al examen,
// ya que en esta unidad se ha enfocado más en la teoría y ha habido una cantidad limitada de ejercicios resueltos para practicar
// y tengo dudas respecto a si escribir directamente en el html, el método agregarPlantasYPuertas, si debería haber usado getters para devolver datos...etc, un saludo!😅