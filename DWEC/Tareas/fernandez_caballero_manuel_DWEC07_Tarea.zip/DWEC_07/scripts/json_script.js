// Implementar una página web, que haciendo uso de JavaScript y del objeto XMLHttpRequest acceda 
// a los datos de la web que te devuelve datos en formato JSON, mediante una petición AJAX, y los muestre en dicha página.

// Utilizo XMLHttpRequest para realizar una solicitud GET a la API de OpenWeatherMap.
// Cuando la solicitud se completa con éxito (estado 200), la función procesa los datos JSON recibidos y los muestra en el HTML.

function getJSONData() {
    // Se crea un nuevo objeto XMLHttpRequest para realizar la solicitud HTTP.
    var xhttp = new XMLHttpRequest();

    // Se establece una función de devolución de llamada para manejar los cambios en el estado de la solicitud.
    xhttp.onreadystatechange = function () {
        // Si la solicitud se ha completado y la respuesta es satisfactoria (estado 200),
        if (this.readyState == 4 && this.status == 200) {
            // Se convierte la respuesta JSON en un objeto JavaScript.
            var jsonData = JSON.parse(this.responseText);
            // Se extraen los datos relevantes del objeto JSON.
            var cityName = jsonData.name;
            var tempValue = jsonData.main.temp;
            var tempUnit = "K"; // Kelvin por defecto
            var humidityValue = jsonData.main.humidity;
            var humidityUnit = "%";

            // Se construye una cadena de salida con los datos obtenidos.
            var jsonOutput = "<p>Ciudad: " + cityName + "</p>";
            jsonOutput += "<p>Temperatura: " + tempValue + " " + tempUnit + "</p>";
            jsonOutput += "<p>Humedad: " + humidityValue + " " + humidityUnit + "</p>";

            // Se actualiza el elemento HTML con id "json-data" con la cadena de salida.
            document.getElementById("json-data").innerHTML = jsonOutput;
        }
    };

    // Se abre la conexión con la API de OpenWeatherMap utilizando las coordenadas proporcionadas.
    // (En este caso, las coordenadas son para Guadalajara, España).
    xhttp.open("GET", "https://api.openweathermap.org/data/2.5/weather?lat=40.6327&lon=-3.1667&appid=54e83ff2db458290e7f13bc490a9022d", true);
    // Se envía la solicitud.
    xhttp.send();
}

// Se llama a la función para obtener y mostrar los datos en formato JSON.
getJSONData();
