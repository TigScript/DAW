// Implementar una página web, que haciendo uso de JavaScript y jQuery,
//  acceda a los datos de la web que te devuelve datos en formato XML y los muestre en dicha página.


// utilizamo jQuery para realizar una solicitud AJAX a la API de OpenWeatherMap y obtener datos en formato XML.
// Una vez que la solicitud se completa con éxito, procesamos los datos XML recibidos y los mostramos en la página.

$(document).ready(function() {
    // defino una función para obtener y mostrar datos XML
    function getXMLData() {
        // Función $.ajax() en jQuery.
        $.ajax({
            type: "GET", // Tipo de solicitud
            url: "https://api.openweathermap.org/data/2.5/weather?q=London&mode=xml&appid=54e83ff2db458290e7f13bc490a9022d", // URL de la API
            dataType: "xml", // Tipo de datos esperados en la respuesta
            success: function(data) { // Función que se ejecuta si la solicitud es exitosa
                // Procesamos los datos XML recibidos
                var cityName = $(data).find('city').attr('name');
                var temperature = $(data).find('temperature').attr('value');
                var tempUnit = $(data).find('temperature').attr('unit');
                var humidity = $(data).find('humidity').attr('value');
                var humidityUnit = $(data).find('humidity').attr('unit');

                // salida de texto de los datos obtenidos
                var xmlOutput = "<p>Ciudad: " + cityName + "</p>";
                xmlOutput += "<p>Temperatura: " + temperature + " " + tempUnit + "</p>";
                xmlOutput += "<p>Humedad: " + humidity + " " + humidityUnit + "</p>";

                // Actualizamos el elemento HTML con id "xml-data" con la cadena de salida
                $("#xml-data").html(xmlOutput);
            },
            error: function(xhr, status, error) { // Función que se ejecuta si hay un error en la solicitud
                console.log("Error al obtener los datos XML: " + error); // Registramos el error en la consola del navegador
            }
        });
    }

    // Llamamos a la función para obtener y mostrar los datos en formato XML
    getXMLData();
});
