// Implementar una página web, que haciendo uso de JavaScript y jQuery,
//  acceda a los datos de la web que te devuelve datos en formato JSON y los muestre en dicha página.



// cuando el ocumento esté completamente cargado ejecuta el codigo:
$(document).ready(function() {
    // utilizola funcion getJSONData se encarga de obtener y mostrar datos en formato JSON
    // utilizo la técnica AJAX para realizar una solicitud GET a la API de OpenWeatherMap
    // cuando la solicitud es exitosa, procesa los datos JSON recibidos y los muestra en el HTML.

    function getJSONData() {
        //  Función $.ajax() en jQuery.
        $.ajax({
            type: "GET", // Tipo de solicitud
            url: "https://api.openweathermap.org/data/2.5/weather?q=London&appid=54e83ff2db458290e7f13bc490a9022d", // URL de la API
            dataType: "json", // Tipo de datos esperados en la respuesta
            success: function(data) { // Función que se ejecuta si la solicitud es exitosa
                // se extraen los datos relevantes del objeto JSON, cualquiera que nos interese
                var cityName = data.name;
                var tempValue = data.main.temp;
                var tempUnit = "K"; // Kelvin por defecto, podriamos hacer uan funcion para mostrarlo en celsius sie s necesario
                var humidityValue = data.main.humidity;
                var humidityUnit = "%";

                // mostramos el texto en el html
                var jsonOutput = "<p>Ciudad: " + cityName + "</p>";
                jsonOutput += "<p>Temperatura: " + tempValue + " " + tempUnit + "</p>";
                jsonOutput += "<p>Humedad: " + humidityValue + " " + humidityUnit + "</p>";

                // se actualiza el elemento HTML con id "json-data"
                $("#json-data").html(jsonOutput);
            },
            error: function(xhr, status, error) { // función que se ejecuta si hay un error en la solicitud
                console.log("Error al obtener los datos JSON: " + error); 
            }
        });
    }

    // llamo a la función getJSONData para obtener y mostrar los datos en formato JSON.
    getJSONData();
});
