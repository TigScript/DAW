// Implementar una página web, que haciendo uso de JavaScript y del objeto XMLHttpRequest acceda a los datos de la web que te devuelve datos en formato XML, mediante una petición AJAX, y los muestre en dicha página.




// Este código utiliza XMLHttpRequest para obtener datos XML del clima de Londres desde la API de OpenWeatherMap.
// Define una función llamada getXMLData que realiza una solicitud GET a la API.
// Cuando la solicitud se completa con éxito (estado 200), extrae la información de temperatura y humedad del XML recibido y la muestra en el HTML.

function getXMLData() {
    // Se crea un nuevo objeto XMLHttpRequest para realizar la solicitud HTTP.
    var xhttp = new XMLHttpRequest();

    // Se establece una función de devolución de llamada para manejar los cambios en el estado de la solicitud.
    xhttp.onreadystatechange = function() {
        // Si la solicitud se ha completado y la respuesta es satisfactoria (estado 200),
        if (this.readyState == 4 && this.status == 200) {
            // Se obtiene el documento XML de la respuesta.
            var xmlDoc = this.responseXML;
            // Se extrae el nombre de la ciudad del documento XML.
            var city = xmlDoc.getElementsByTagName("city")[0];
            var cityName = city.getAttribute("name");
            // Se extrae la temperatura del documento XML.
            var temperature = xmlDoc.getElementsByTagName("temperature")[0];
            var tempValue = temperature.getAttribute("value");
            var tempUnit = temperature.getAttribute("unit");
            // Se extrae la humedad del documento XML.
            var humidity = xmlDoc.getElementsByTagName("humidity")[0];
            var humidityValue = humidity.getAttribute("value");
            var humidityUnit = humidity.getAttribute("unit");
            
            // Se construye una cadena de salida con los datos obtenidos.
            var xmlOutput = "<p>City: " + cityName + "</p>";
            xmlOutput += "<p>Temperature: " + tempValue + " " + tempUnit + "</p>";
            xmlOutput += "<p>Humidity: " + humidityValue + " " + humidityUnit + "</p>";
            
            // Se actualiza el elemento HTML con id "xml-data" con la cadena de salida.
            document.getElementById("xml-data").innerHTML = xmlOutput;
        }
    };
    
    // Se abre la conexión con la API de OpenWeatherMap utilizando la URL proporcionada.
    xhttp.open("GET", "https://api.openweathermap.org/data/2.5/weather?q=London&mode=xml&appid=54e83ff2db458290e7f13bc490a9022d", true);
    // Se envía la solicitud.
    xhttp.send();
}

// Se llama a la función para obtener y mostrar los datos en formato XML.
getXMLData();

// Se actualizan los datos cada 5 minutos.
setInterval(getXMLData, 5 * 60 * 1000); // 5 minutos en milisegundos
