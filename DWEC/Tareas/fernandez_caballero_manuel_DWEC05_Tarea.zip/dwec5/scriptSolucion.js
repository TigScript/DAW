//1.Escribo el código en un fichero js independiente con el mismo nombre que presenta al del archivo index.html
//2.Almacenar en una cookie el número de intentos de envío del formulario que se van produciendo y mostrar un mensaje en el contenedor "intentos" similar a: "Intento de Envíos del formulario: X". Es decir cada vez que le demos al botón de enviar tendrá que incrementar el valor de la cookie en 1 y mostrar su contenido en el div antes mencionado.
//Nota: para poder actualizar el contenido de un contenedor o div la propiedad que tenemos que modificar para ese objeto es innerHTML.
//Este apartado lo he realizado con un poco de "ayuda externa", 
//ya que en esta unidad se menciona al principio"Por último se hace una introducción a lo que son las cookies y cómo gestionarlas con JavaScript.""
//Pero yo no he encontrado nada al respecto, y aunque la validación de cookies de la asignatura de DWES puede ayudar un poco, no manejamos sesiones en este ejercicio...


// Cuando la página está completamente cargada, se ejecuta la función "iniciar"
window.onload = iniciar;

// Variable para almacenar mensajes de error
var errores = "";

// Función que se ejecuta al cargar la página y comenzar la ejecución de JS
function iniciar() {
  // Comprobamos si hay un contador en el almacenamiento local; si no, lo inicializamos a 0
  if (!localStorage.getItem("contador")) {
    localStorage.setItem("contador", 0);
  }

  // Desactiva la función por defecto del botón "enviar", si no se enviaría el formulario aun con la validación final
  document.getElementById("enviar").addEventListener("click", function(e) {
    validarFormulario(e);
  }, false);

  // Creamos eventos para que los campos ejecuten la función "toMayus()" 
  document.getElementById("nombre").addEventListener("blur", toMayus);
  document.getElementById("apellidos").addEventListener("blur", toMayus);
}

// Función que actualiza los mensajes de error
function actualizarErrores() {
  // Obtiene el valor de la variable "errores" y lo muestra en el HTML de <div id="errores"> 
  document.getElementById("errores").innerHTML = errores;
  // Cada vez que se actualizan los errores, se incrementa en 0.5 el contador de errores
  incrementarContador(0.5);
  // Uso un float porque al llamar a la función incrementarContador dos veces se suma de dos en dos, así que como se cuenta dos veces pongo 0,5 y hago un parsefloat, seguramente haya una solución más facil 
  // Al incrementar el valor, no sé por qué se incrementa de dos en dos, el console.log muestra lo siguiente: 
  // 65  scriptSolucion.js:41
  // 66  scriptSolucion.js:41
}

// Función que incrementa el contador de errores
function incrementarContador(incremento) {
  // Obtiene el valor actual del contador del almacenamiento local
  let valor = parseFloat(localStorage.getItem("contador"));

  // Incrementa el valor del contador por el incremento proporcionado
  valor += incremento;

  // Muestra el valor del contador por consola antes de actualizar el almacenamiento local
  console.log(valor);

  // Actualiza el valor del contador en el almacenamiento local
  localStorage.setItem("contador", valor);

  // Muestra el mensaje de número de intentos y el valor del contador en el HTML de <div id="intentos">
  document.getElementById("intentos").innerHTML = "Intento de Envíos del formulario: " + valor;
}


//3.Cada vez que los campos NOMBRE y APELLIDOS pierdan el foco, el contenido que se haya escrito en esos campos se convertirá a mayúsculas.
//Función que cambia el texto de los campos "nombre" y "apellidos" a mayúsculas cuando se les quita el foco
function toMayus(element) {
  let texto = document.getElementById(element.target.id);
  texto.value = texto.value.toUpperCase();
}
//4.Realizar una función que valide los campos de texto NOMBRE y APELLIDOS. Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en los campos correspondientes.
//Función para comprobar el nombre introducido en el formulario
function validarNombre() {
  //Añado el elemento nombre a una variable y compruebo si su valor es una cadena vacía
  var nombre = document.getElementById("nombre");
  //Comprobamos si el valor de ese elemento estaba vacío
  if (nombre.value == "") {
    //si esta vacío muestro mensaje de error
    errores = "El nombre es obligatorio";
    //Pongo el foco con .focus sobre nombre
    document.getElementById("nombre").focus();
    //Asigno la clase de error para que se aplique el css
    document.getElementById("nombre").className = "error";
    actualizarErrores();
    return false;
  } else {
    //En caso de que no haya errores, eliminamos el nombre de clase por si tenía asignado "error"
    document.getElementById("nombre").className = "";
    return true;
  }
}

//Repito el mismo procedimiento para el campo apellidos"
function validarApellidos() {
  var apellidos = document.getElementById("apellidos");
  if (apellidos.value == "") {
    errores = "El campo apellidos es obligatorio";
    document.getElementById("apellidos").focus();
    document.getElementById("apellidos").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("apellidos").className = "";
    return true;
  }
}
// 5.Validar la EDAD que contenga solamente valores numéricos y que esté en el rango de 0 a 105. Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo EDAD.
function validarEdad() {
  //Asigno a una variable el elemento con ID "edad" como en cada caso anterior, pero al ser un número, hago un parseInt y almaceno su valor en "edad"
  var edad = document.getElementById("edad");
  edad = parseInt(edad.value);
  //si edad isNaN, "is not a number", actualizamos el mensaje de error
  if (isNaN(edad)) {
    errores = "La edad debe ser un valor numérico";
    document.getElementById("edad").focus(); //ponemos el foco sobre el campo como antes
    document.getElementById("edad").className = "error"; //y le damos el estillo de error como antes
    actualizarErrores();
    return false;
    //Si la edad es un numero, comprobamos que esta entre el rango de 0 a 1005
  } else if (edad < 0 || edad > 105) {
    errores = "La edad debe estar en un rango de 0 a 105";
    document.getElementById("edad").focus();
    document.getElementById("edad").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("edad").className = "";
    return true;
  }
}

//6.Validar el NIF. Utilizar una expresión regular que permita solamente 8 números un guión y una letra. Si se produce algún error mostrar el mensaje en el contenedor "errores"
//y poner el foco en el campo NIF. No es necesario validar que la letra sea correcta. Explicar las partes de la expresión regular mediante comentarios.
function validarNif() {
  var nif = document.getElementById("nif");
  //   ^: Indica que la coincidencia debe ocurrir al principio de la cadena.
  // \d{8}: significa que se esperan exactamente 8 dígitos.
  // -: es el guión que se espera después de los 8 digitos
  // [a-zA-Z]: cualquier letra mayúscula o minúscula.
  // $: Indica que la coincidencia debe ocurrir al final de la cadena.
  const regexNif = /^\d{8}-[a-zA-Z]$/;
  //Comprobamos como en los anteriores casosq ue el campo no este vacío..
  if (nif.value == "") {
    errores = "El NIF es obligatorio.";
    document.getElementById("nif").focus();
    document.getElementById("nif").className = "error";
    actualizarErrores();
    return false;
  } else if (!regexNif.test(nif.value)) {
    errores = "Formato del NIF incorrecto.";
    document.getElementById("nif").focus();
    document.getElementById("nif").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("nif").className = "";
    return true;
  }
}

// 7.Validar el E-MAIL. Utilizar una expresión regular que nos permita comprobar que el e-mail sigue un formato correcto.
//  Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo E-MAIL. Explicar las partes de la expresión regular mediante comentarios.
function validarEmail() {
  var email = document.getElementById("email");
  const regexMail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
  //  ^: Indica que la coincidencia debe ocurrir al principio de la cadena.
  // [a-zA-Z0-9._-]+: Coincide con uno o más caracteres que pueden ser letras (mayúsculas o minúsculas), dígitos, o los caracteres especiales ".", "_", o "-". Representando la aprte hasta el  @ del correo
  // @: Coincide con el símbolo "@".
  // [a-zA-Z0-9.-]+: Coincide con uno o más caracteres que pueden ser letras (mayúsculas o minúsculas), dígitos, o los caracteres especiales ".", o "-". Representando el dominio del correo electrónico.
  // \.: Coincide con el punto literal "." que separa el dominio de nivel superior (TLD).
  // [a-zA-Z]{2,4}$: Coincide con entre 2 y 4 letras al final de la cadena, representando el TLD (por ejemplo, com, org, es).
  // $: Indica que la coincidencia debe ocurrir al final de la cadena.

  //Comprobamos si el campo está vacío
  if (email.value == "") {
    errores = "El correo electrónico es obligatorio";
    document.getElementById("email").focus();
    document.getElementById("email").className = "error";
    actualizarErrores();
    return false;
    //Comprobacion del formato regex
  } else if (!regexMail.test(email.value)) {
    errores = "Error en la formulación del e-mail";
    document.getElementById("email").focus();
    document.getElementById("email").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("email").className = "";
    return true;
  }
}

// 8.Validar que se haya seleccionado alguna de las PROVINCIAS. Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo PROVINCIA.
//Función para comprobar que se ha seleccionado una provincia.
function validarProvincia() {
  var provincia = document.getElementById("provincia");
  //Si su valor es igual a 0, el valor por defecto, "Seleccione una provincia", manejaremos el error
  if (provincia.value == 0) {
    errores = "Seleccione una provincia"; //error
    document.getElementById("provincia").focus(); //foco
    document.getElementById("provincia").className = "error"; //estilos
    actualizarErrores();
    return false;
  } else {
    document.getElementById("provincia").className = "";
    return true;
  }
}

// 9.Validar el campo FECHA utilizando una expresión regular. Debe cumplir alguno de los siguientes formatos: dd/mm/aaaa o dd-mm-aaaa.
// No se pide validar que sea una fecha de calendario correcta. Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo FECHA.
// Explicar las partes de la expresión regular mediante comentarios.
function validarFecha() {
  var fecha = document.getElementById("fecha");
  const regexFecha = /^(0[1-9]|[1-2][0-9]|3[0-1])[-\/](0[1-9]|1[0-2])[-\/]\d{4}$/; //Estoy utilizando constantes para regex ya que en principio no van a cambiar pero podría utilizar var también
  //   ^: Indica que la coincidencia debe ocurrir al principio de la cadena.
  // (0[1-9]|[1-2][0-9]|3[0-1]): Este grupo representa los días en formato dd. Puede ser del 01 al 09, del 10 al 29, o del 30 al 31.
  // [-\/]: Coincide con un guion o una barra inclinada, que separa la parte del día de la parte del mes.
  // (0[1-9]|1[0-2]): Este grupo representa los meses en formato mm. Puede ser del 01 al 09 o del 10 al 12.
  // [-\/]: Otro guion o barra inclinada, que separa la parte del mes de la parte del año.
  // \d{4}: Coincide con exactamente cuatro dígitos, que representan el año.
  // $: Indica que la coincidencia debe ocurrir al final de la cadena.

  //Comprobamos que el cambo esté vacío...
  if (fecha.value == "") {
    errores = "La fecha es obligatoria";
    document.getElementById("fecha").focus(); //foco
    document.getElementById("fecha").className = "error"; //estilos
    actualizarErrores();
    return false;
    //Si el formato no se corresponde con la expresión regular, salta un error
  } else if (!regexFecha.test(fecha.value)) {
    errores = "Escriba el formato de la fecha dd-mm-yyyy o dd/mm/yyyy";
    document.getElementById("fecha").focus();
    document.getElementById("fecha").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("fecha").className = "";
    return true;
  }
}

// 10.Validar el campo TELEFONO utilizando una expresión regular. Debe permitir 9 dígitos obligatorios.
//Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo TELEFONO. Explicar las partes de la expresión regular mediante comentarios.
function validarTelefono() {
  var telefono = document.getElementById("telefono").value;
  var regexTelefono = /^\d{9}$/;
  // ^: Indica que la coincidencia debe ocurrir al principio de la cadena.
  // \d{9}: Coincide exactamente con nueve dígitos. \d es una clase de caracteres que representa cualquier dígito (0-9), y {9} indica que se espera exactamente 9 repeticiones.
  // $: Indica que la coincidencia debe ocurrir al final de la cadena.

  //comprobación de cadena vacía...
  if (telefono === "") {
    errores = "El teléfono es obligatorio";
    document.getElementById("telefono").focus(); // Foco
    document.getElementById("telefono").className = "error"; // Estilos
    actualizarErrores();
    return false;
  }
  // Comprobación del formato
  else if (!regexTelefono.test(telefono)) {
    errores = "Escriba 9 dígitos para el teléfono";
    document.getElementById("telefono").focus();
    document.getElementById("telefono").className = "error";
    actualizarErrores();
    return false;
  }
  // Restablecer estilos y devolver true si todo está bien
  else {
    document.getElementById("telefono").className = "";
    return true;
  }
}

// 11.Validar el campo HORA utilizando una expresión regular. Debe seguir el patrón de hh:mm. No es necesario validar que sea una hora correcta.
// Si se produce algún error mostrar el mensaje en el contenedor "errores" y poner el foco en el campo HORA. Explicar las partes de la expresión regular mediante comentarios.
function validarHora() {
  var hora = document.getElementById("hora");
  var regexHora = /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
  // ^: Indica que la coincidencia debe ocurrir al principio de la cadena.
  // (0[0-9]|1[0-9]|2[0-3]): Coincide con horas en formato 00-09, 10-19, o 20-23.
  // : : Coincide con dos puntos que separan las horas de los minutos.
  // [0-5][0-9]: Coincide con minutos en formato 00-59.
  // $: Indica que la coincidencia debe ocurrir al final de la cadena.

  //Comprobación de campo vacío
  if (hora.value == "") {
    errores = "Campo hora vacío.";
    document.getElementById("hora").focus();
    document.getElementById("hora").className = "error";
    actualizarErrores();
    return false;
    //Comprobación de la expresion regular
  } else if (!regexHora.test(hora.value)) {
    errores = "Formato de hora incorrecto. Debe seguir el patrón hh:mm.";
    document.getElementById("hora").focus();
    document.getElementById("hora").className = "error";
    actualizarErrores();
    return false;
  } else {
    document.getElementById("hora").className = "";
    return true;
  }
}
// 12.Pedir confirmación de envío del formulario. Si se confirma el envío realizará el envío de los datos; en otro caso cancelará el envío.
function validarFormulario(e) {
  // Reinicializar errores
  errores = "";
  if (validarNombre() && validarApellidos() && validarEdad()
    && validarNif() && validarEmail() && validarProvincia()
    && validarFecha() && validarTelefono() && validarHora()
    && confirm("Confirme para enviar los datos.")) {
    return true;
  } else {
    actualizarErrores();
    e.preventDefault();
    return false;
  }
}
