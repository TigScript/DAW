<?php
//Comenzamos la sesión
session_start();
require '../vendor/autoload.php';
use Clases\Conexion;


$insertar = (new Conexion())->crearConexion();




//Si ya hay una sesión activa con datos asignados, los asignamos a variables
if(isset($_SESSION['nombre'])){
    $nombre = $_SESSION['nombre'];
    $apellidos = $_SESSION['apellidos'];
    $dorsal = $_SESSION['dorsal'];
    // $posicion = $_SESSION['posicion'];
    $posicion = 'Defensa';

    $barcode = $_SESSION['barcode'];
    $_SESSION ['mensaje'] = "";
} else{
    header("Location:fcrear.php");
}
//Creamos variables con todos los datos necesarios para crear un jugador y le damos el valor "true"
$nombreCorrecto = true;
$apellidoCorrecto = true;
$dorsalCorrecto = true;
$barcodeCorrecto = true;
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$dorsal = $_POST['dorsal'];
$posicion = $_POST['posicion'];
$barcode = $_POST['barcode'];




//Controlaremos que nombre  no esté vacíos
if(empty(trim($nombre))){
    //Cambiamos el valor de la variable a "false"
    $nombreCorrecto = false;
    $_SESSION['mensaje'].="Debes introducir un nombre</br>";
}
//Controlaremos que  apellidos no esté vacíos
if(empty(trim($apellidos))){
    //Cambiamos el valor de la variable a "false"
    $apellidoCorrecto = false;
    $_SESSION['mensaje'].="Debes introducir apellidos</br>";
}

//Controlamos que el código de barras no esté vacío
if(empty($barcode)){
    //Cambiamos el valor de la variable a "false"
    $barcodeCorrecto = false;
    $_SESSION['mensaje'].="Código de barras vacío</br>";
}
//Si el dorsal que hemos selcecionado ya está en la base de datos mostramos mensaje de error
// $mirarDorsal = $insertar->query('SELECT * FROM jugadores WHERE dorsal='.$dorsal.'');
$mirarDorsal = $insertar->query('SELECT * FROM jugadores WHERE dorsal='.$dorsal.'');

if ($dorsal == 0) {
    $dorsal = 'Sin asignar';
} else {
    // Hacemos la comparación correcta para verificar si el dorsal ya está en uso
    if (!$mirarDorsal->rowCount() == 0) {
        // Cambiamos el valor de la variable a "false"
        $dorsalCorrecto = false;
        $_SESSION['mensaje'] .= "Dorsal ya en uso</br>";
    }
}

//Si no ha habido ningún error añadimos el jugador a la base de datos
if($nombreCorrecto && $apellidoCorrecto && $dorsalCorrecto && $barcodeCorrecto){

    try{
        //Añadimos al jugador a la base de datos
        $addJugador = $insertar->query("INSERT INTO jugadores
        (nombre, apellidos, dorsal, posicion, barcode)
        VALUES ('$nombre', '$apellidos', '$dorsal', '$posicion', '$barcode')");
       
    }catch(PDOException $e){
        die("Error al insertar datos: ".$e->getMessage());
    }
    //Y volvemos a la página jugadores.php
    header("Location:jugadores.php");
    //Si ha habido algún error, nos devuelve a la página para crear jugador
} else{
    header("Location:fcrear.php");
}