<?php
session_start();
require '../vendor/autoload.php';
//Esta página genera los códigos de barras para el formulario de crear jugador
use Clases\Conexion;
//Creamos un objeto faker
$faker = Faker\Factory::create('es_ES');
//Creamos la conexión
$insertar = (new Conexion())->crearConexion();

while(true){
    //Asignamos a la variable $codigo un número ean13 aleatorio
    $codigo = $faker->ean13;
    //Buscamos ese número en la base de datos
    $stmt = $insertar->query('SELECT barcode FROM jugadores WHERE barcode='.$codigo.'');
    //Si la base de datos no nos devuelve nada, significa que ese código no está en uso
    if($stmt->rowCount()==0){
        //Asignamos ese barcode a una variable de sesión
        $_SESSION['barcode']=$codigo;
        //Y rompemos el bucle. En caso de que ese código ya esté en uso, seguirá generando códigos hasta encontrar uno libre
        break;
    }
}

//Volvemos a la página del formulario para crear jugador
header("Location:fcrear.php");