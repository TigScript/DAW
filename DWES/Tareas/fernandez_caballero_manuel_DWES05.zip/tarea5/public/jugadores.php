<?php
//Página con la lista de jugadores
require '../vendor/autoload.php';
use Philo\Blade\Blade;
use Clases\Jugador;
use \Milon\Barcode\DNS1D;
$views = '../views';
$cache = '../cache';
$titulo= "Inicio";
$cabecera ="Listado de jugadores";
//Creamos una conexión y hacemos una petición de todos los jugadores que hay en la base dea datos
$listaJugadores= (new Jugador())->getJugadores();
$blade = new Blade($views, $cache);
//Creamos el objeto de Milon\Barcode (lo que dibuja los códigos de barras)
$d = new DNS1D();
$d->setStorPath(__DIR__.'/cache/');
//Blade "dibuja" la página
echo $blade->view()->make('vjugadores', compact('titulo', 'cabecera', 'listaJugadores', 'd'))->render();