<?php
// Inicializa la sesión si no está iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Inicializa las variables de sesión si no están definidas
if (!isset($_SESSION['nombre'])) {
    $_SESSION['nombre'] = '';
}

if (!isset($_SESSION['apellidos'])) {
    $_SESSION['apellidos'] = '';
}

if (!isset($_SESSION['dorsal'])) {
    $_SESSION['dorsal'] = 0;
}

if (!isset($_SESSION['barcode'])) {
    $_SESSION['barcode'] = '';
}

// Esta página carga la plantilla de blade con el formulario para crear jugador
require '../vendor/autoload.php';
use Philo\Blade\Blade;
use Clases\Jugador;
use \Milon\Barcode\DNS1D;

// Indicamos dónde están las carpetas "views" y "cache"
$views = '../views';
$cache = '../cache';

// Le asignamos los valores de las variables "Título" y "Cabecera" que están indicadas en la plantilla
$titulo = "Página para crear jugador";
$cabecera = "Crear jugador";

// Creamos un objeto Blade
$blade = new Blade($views, $cache);

// Creamos la conexión
$jugadores = (new Jugador())->getJugadores();

// Creamos un array de posiciones
$posiciones = ["Portero", "Defensa", "Lateral Izquierdo", "Lateral Derecho", "Central", "Delantero"];

// Hacemos que Blade "dibuje" la página
echo $blade->view()->make('vcrear', compact('titulo', 'cabecera', 'jugadores', 'posiciones'))->render();
?>
