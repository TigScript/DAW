<!-- Plantilla para la página que crea los datos de ejemplo. Le especificamos las secciones,
y las variables las sacará de la propia página que use esta vista-->
<?php $__env->startSection('titulo'); ?>
    <?php echo e($titulo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cabecera'); ?>
    <?php echo e($cabecera); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <a href="crearDatos.php" type="button" class="btn btn-success" >Insertar datos de ejemplo</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantillaComun', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>