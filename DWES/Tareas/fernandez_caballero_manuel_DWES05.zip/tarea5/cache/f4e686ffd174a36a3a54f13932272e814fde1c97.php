 <!-- Extiende la plantillaComun -->

<?php $__env->startSection('titulo'); ?> <!-- Sección para el título -->
    <?php echo e($titulo); ?> <!-- Muestra el título -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cabecera'); ?> <!-- Sección para la cabecera -->
    <?php echo e($cabecera); ?> <!-- Muestra la cabecera -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?> <!-- Sección para el contenido -->

<div class="container "> <!-- Contenedor principal -->
    <div class="row"> <!-- Fila -->
        <div class="col-md-6"> <!-- Columna -->
            <!-- <form method="post" action="<?php echo e($_SERVER['PHP_SELF']); ?>"> 
                Formulario para enviar datos -->
            <form method="post" action="<?php echo ('../public/crearJugador.php'); ?>"> <!-- Formulario para enviar datos -->

                <label for="nombre">Nombre</label> <!-- Etiqueta para el nombre -->
                <input type="text" name="nombre" value="<?php echo e($_SESSION['nombre']); ?>" required> <!-- Campo para el nombre -->
        </div>
        <div class="col-md-6"> <!-- Columna -->
            <label for="apellidos">Apellidos</label> <!-- Etiqueta para los apellidos -->
            <input type="text" name="apellidos" value="<?php echo e($_SESSION['apellidos']); ?>" required> <!-- Campo para los apellidos -->
        </div>
        <div class="col-md-6"> <!-- Columna -->
            <label for="posicion">Posición</label> <!-- Etiqueta para la posición -->
            <select name="posicion" id="posicion"> <!-- Lista desplegable para la posición -->
                <?php $__currentLoopData = $posiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Bucle para recorrer las posiciones -->
                    <option value="<?php echo e($pos); ?>"><?php echo e($pos); ?></option> <!-- Opción para cada posición -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-md-6"> <!-- Columna -->
            <label for="dorsal">Dorsal</label> <!-- Etiqueta para el dorsal -->
            <input type="number" name="dorsal" min="1" max="99" value="<?php echo e($_SESSION['dorsal']); ?>"></br> <!-- Campo para el dorsal -->
        </div>
    </div>
    <div class="row"> <!-- Fila -->
        <div class="col-md-6"> <!-- Columna -->
            <label for="Código de barras">Código de barras</label> <!-- Etiqueta para el código de barras -->
            <input type="text" id="barcode" name="barcode" value="<?php echo e($_SESSION['barcode']); ?>" readonly> <!-- Campo para el código de barras (solo lectura) -->
        </div>
        <div class="col-md-1"><input class="btn btn-primary float-left" type="submit" name="submit" value="Crear"></div> <!-- Botón para enviar el formulario -->
        <div class="col-md-1"><input class="btn btn-success float-left" type="reset" name="borrar" value="Limpiar"></div> <!-- Botón para resetear el formulario -->
        <div class="col-md-1">
    <a href="jugadores.php" class="btn btn-info float-left">Volver</a>
</div>

        <div class="col-md-1"><input class="btn btn-secondary float-left" type="submit"  name="sendBar" id="sendBar" value="Generar código" ></div> <!-- Botón para generar código de barras -->
    </form>
</div>
</div>

<?php $__env->stopSection(); ?> <!-- Fin de la sección de contenido -->

<?php echo $__env->make('plantillas.plantillaComun', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>