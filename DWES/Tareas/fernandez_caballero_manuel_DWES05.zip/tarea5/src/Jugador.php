<?php

    namespace Clases;
    use PDO;
    use PDOException;
//Clase jugador, extiende a la clase conexión
class Jugador extends Conexion{
    //Usa el mismo constructor que la clase Conexion
    public function __construct(){
        parent::__construct();
    }

    //Función que, una vez conectado, hace una consulta a la base de datos que devuelve todos los jugadores como objetos
    public function getJugadores(){
        $consulta = "SELECT * FROM jugadores";
        $stmt = $this->conexion->prepare($consulta);
        try{
            $stmt->execute();
        } catch(PDOException $e){
            die("Error al obtener datos: ".$e->getMessage());
        }
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
}