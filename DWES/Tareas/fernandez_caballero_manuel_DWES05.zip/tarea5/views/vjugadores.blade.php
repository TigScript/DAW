@extends('plantillas.plantillaComun')
<!-- Plantilla para la página que muestra los jugadores. Le especificamos las secciones,
y las variables las sacará de la propia página que use esta vista-->
@section('titulo')
    {{$titulo}}
@endsection

@section('cabecera')
    {{$cabecera}}
@endsection

@section('contenido')

<?php
session_start();

if(isset($_SESSION['mensaje'])){
    print "<div class=\"mensajeCreado\">".$_SESSION['mensaje']."</div>";
    session_destroy();
}

?>

<div id="botonNuevoJugador">

<a href="fcrear.php" class="btn btn-success btn-nuevoJugador float-left" style="margin-bottom: 20px"><i class="fas fa-plus"></i> Nuevo Jugador</a>

</div>

<div class="contieneTabla">

    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellidos</th>
                <th scope="col">Dorsal</th>
                <th scope="col">Posición</th>
                <th scope="col">Código de barras</th>
            </tr>
        </thead>
        <tbody>
            <!-- Igual que antes, en lugar de abrir tags de php, usamos los tags de Blade para ejecutar PHP -->
            @foreach($listaJugadores as $item)
            <tr scope="row">
                <td>{{$item->id}}</td>
                <td>{{$item->nombre}}</td>
                <td>{{$item->apellidos}}</td>
                <td>{{$item->dorsal}}</td>
                <td>{{$item->posicion}}</td>
                <td>{!!$d->getBarcodeHTML($item->barcode, 'EAN13', 2,45, 'white', true)!!}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection