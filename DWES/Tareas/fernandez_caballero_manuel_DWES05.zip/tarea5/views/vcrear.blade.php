
@extends('plantillas.plantillaComun') <!-- Extiende la plantillaComun -->

@section('titulo') <!-- Sección para el título -->
    {{ $titulo }} <!-- Muestra el título -->
@endsection

@section('cabecera') <!-- Sección para la cabecera -->
    {{ $cabecera }} <!-- Muestra la cabecera -->
@endsection

@section('contenido') <!-- Sección para el contenido -->

<div class="container "> <!-- Contenedor principal -->
    <div class="row"> <!-- Fila -->
        <div class="col-md-6"> <!-- Columna -->
            <!-- <form method="post" action="{{ $_SERVER['PHP_SELF'] }}"> 
                Formulario para enviar datos -->
            <form method="post" action="{{ $_SERVER['crearJugador.php'] }}"> <!-- Formulario para enviar datos -->

                <label for="nombre">Nombre</label> <!-- Etiqueta para el nombre -->
                <input type="text" name="nombre" value="{{ $_SESSION['nombre'] }}" required> <!-- Campo para el nombre -->
        </div>
        <div class="col-md-6"> <!-- Columna -->
            <label for="apellidos">Apellidos</label> <!-- Etiqueta para los apellidos -->
            <input type="text" name="apellidos" value="{{ $_SESSION['apellidos'] }}" required> <!-- Campo para los apellidos -->
        </div>
        <div class="col-md-6"> <!-- Columna -->
            <label for="posicion">Posición</label> <!-- Etiqueta para la posición -->
            <select name="posicion" id="posicion"> <!-- Lista desplegable para la posición -->
                @foreach($posiciones as $pos) <!-- Bucle para recorrer las posiciones -->
                    <option value="{{ $pos }}">{{ $pos }}</option> <!-- Opción para cada posición -->
                @endforeach
            </select>
        </div>

        <div class="col-md-6"> <!-- Columna -->
            <label for="dorsal">Dorsal</label> <!-- Etiqueta para el dorsal -->
            <input type="number" name="dorsal" min="1" max="99" value="{{ $_SESSION['dorsal'] }}"></br> <!-- Campo para el dorsal -->
        </div>
    </div>
    <div class="row"> <!-- Fila -->
        <div class="col-md-6"> <!-- Columna -->
            <label for="Código de barras">Código de barras</label> <!-- Etiqueta para el código de barras -->
            <input type="text" id="barcode" name="barcode" value="{{ $_SESSION['barcode'] }}" readonly> <!-- Campo para el código de barras (solo lectura) -->
        </div>
        <div class="col-md-1"><input class="btn btn-primary float-left" type="submit" name="submit" value="Crear"></div> <!-- Botón para enviar el formulario -->
        <div class="col-md-1"><input class="btn btn-success float-left" type="reset" name="borrar" value="Limpiar"></div> <!-- Botón para resetear el formulario -->
        <div class="col-md-1">
    <a href="jugadores.php" class="btn btn-info float-left">Volver</a>
</div>

        <div class="col-md-1"><input class="btn btn-secondary float-left" type="submit"  name="sendBar" id="sendBar" value="Generar código" ></div> <!-- Botón para generar código de barras -->
    </form>
</div>
</div>

@endsection <!-- Fin de la sección de contenido -->
