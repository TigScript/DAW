<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Listado</title>
</head>

 <body>

    <!--miEmpresa-->
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <span class="navbar-brand font-weight-bold">MiEmpresa</span>
        <div class="ml-auto">
            <span class="navbar-text font-weight-bold text-dark">Gestión de Incidencias</span>
        </div>
    </nav>

    <div class="container mt-4">

        <h3 class="mb-4">Incidencias registradas:</h3>

        <?php
        require_once('conexion.php'); 

        $query = $conexion->query('SELECT * FROM incidencias'); //ejecutamos sentencia
        $query->execute();

        if ($query->rowCount() > 0) { //mostramos los datos si hay algo almacenado, y si no hemos añadido nada aún mostramos el mensaje de que actualmente no hay incidencias
        ?>
            <table class="table table-striped table-dark text-center">
                <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Error</th>
                        <th scope="col">Prioridad</th>
                        <th scope="col">Estado</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = $query->fetch(PDO::FETCH_OBJ)) {
                    ?>
                        <tr>
                            <td><?php echo $row->nombre; ?></td>
                            <td><?php echo $row->titulo; ?></td>
                            <td><?php echo $row->prioridad; ?></td>
                            <td><?php echo $row->estado; ?></td>
                            <td>
                                <form action="detalle.php" method="GET" class="d-inline-block"> <!-- d-inline-block para alinear los botones-->
                                    <input type="hidden" name="id" value="<?php echo $row->id; ?>">
                                    <button class="btn btn-info btn-sm">Ver</button>
                                </form>

                                <form action="update.php" method="GET" class="d-inline-block">
                                    <input type="hidden" name="id" value="<?php echo $row->id; ?>">
                                    <button class="btn btn-warning btn-sm">Actualizar</button>
                                </form>

                                <form action="borrar.php" method="POST" class="d-inline-block"> <!-- metodo post-->
                                    <input type="hidden" name="id" value="<?php echo $row->id; ?>">
                                    <button class="btn btn-danger btn-sm">Borrar</button>
                                </form>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        <?php
        } else {
            echo '<p>Actualmente no tiene incidencias.</p>';
        }
        ?>

        <form action="crear.php" method="GET" class="mb-1">
            <button class="btn btn-success">Agregar incidencia</button>
        </form>

    </div>

</body>

</html>
