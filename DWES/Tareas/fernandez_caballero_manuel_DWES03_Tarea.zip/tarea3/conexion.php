<?php
//opciones de la conexion, para acentos, eñes, etc... utf8mb4 para usar emojis
$opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
//defino la constant ubicacion y nombre de la base de datos, user, pass 
//ubicacion de la base de datos
define("HOST_DB","localhost");
//usuario de la base de datos que se conecta
define("USER_DB", "root");
//contraseña del usuario
define("PASS_DB","");
//Nombre de la base de datos
define("NAME_DB","test");
//al usar XAMPP en windows y no tener un usuario y contraseña definiido, con root y sin pass entramos
try {
    $conexion = new PDO(
        'mysql:host='.constant("HOST_DB").';dbname='.constant("NAME_DB"),
        constant("USER_DB"),
        constant("PASS_DB"),
        $opciones
    );
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit;
}

// Para obtener la conexion utilizando MySqli en lugar de PDO se seguiria la siguiente estructura:
// @$conProyecto = new mysqli('localhost', 'gestor', 'secreto', 'proyecto');
// $error = $conProyecto->connect_errno;
// if ($error != null) {
//      echo "<p>Error $error conectando a la base de datos: $conProyecto->connect_error</p>";
//      die();
// }
// Donde conProyecto es el nombre de la xonexion con @, el operador de control de errores, rellenando los parametros de ('servidor', 'usuario', 'contraseña', 'base_de_datos');

?>

