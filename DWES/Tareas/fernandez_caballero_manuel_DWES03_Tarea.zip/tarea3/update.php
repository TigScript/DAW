<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Actualizar</title>
</head>

<body>
    <!--miEmpresa-->
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <span class="navbar-brand font-weight-bold">MiEmpresa</span>
        <div class="ml-auto">
            <span class="navbar-text font-weight-bold text-dark">Gestión de Incidencias</span>
        </div>
    </nav>
    <div style="text-align: center;">
        <h3 class="mb-4" style="strong">Actualizar</h3>
        <p> Modifica la incidencia rellenando los campos en el formulario </p>
    </div>


    <div class="container">

        <?php
        require_once('conexion.php');


        if (isset($_POST['modificar'])) {
            $id = $_POST['id'];
            $nombre = $_POST['nombre'];
            $titulo = $_POST['titulo'];
            $descripcion = $_POST['descripcion'];
            $archivo = $_POST['archivo'];
            $prioridad = $_POST['prioridad'];

            $sql = "UPDATE incidencias SET nombre = '$nombre', titulo = '$titulo', descripcion = '$descripcion', archivo = '$archivo', prioridad = '$prioridad' WHERE id = $id";
            $insert = $conexion->query($sql);
            $insert->execute();

            header('Location: listado.php');

        }

        if (!isset($_GET['id']) || isset($_POST['volver'])) { //si no tiene id redirigimos atrás al usuario
            header("Location: listado.php");
        } else {

            $id = $_GET['id'];
            $sql = "SELECT * FROM incidencias WHERE id = $id";
            $result = $conexion->query($sql);
            $result->execute();
            $incidencia = $result->fetch(PDO::FETCH_OBJ);

            if ($incidencia == null) { //redirigir a listado.php cuando el codigo de la incidencia no existe
                header("Location: listado.php");
            }
        }


        ?>
            




       

        <form method="POST">

<input type="hidden" name="id" value="<?php echo $incidencia->id; ?>">


            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <label for="nombre">Nombre: </label>
                        <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo $incidencia->nombre?>" /> <!-- obtenemos el valor del nombre, para que se muestren los datos -->
                    </div>
                    <div class="col-6">
                        <label for="titulo">Título: </label>
                        <input type="text" class="form-control" name="titulo" id="titulo" value="<?php echo $incidencia->titulo?>" />
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-12">
                        <label for="descripcion">Descripción: </label>
                        <textarea class="form-control" name="descripcion" id="descripcion" cols="100"
                            rows="10"><?php echo $incidencia->titulo?></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <p> Adjunta un archivo si lo deseas: </p>
                        <input type="file" class="form-control" name="archivo" id="archivo" />
                    </div>
                </div>
                <br>


                <div class="col-12">
                    <label for="prioridad">Prioridad: </label>
                    <select class="form-control" name="prioridad" id="prioridad" class="col-6">
    <?php                  
    $query = "SHOW COLUMNS FROM incidencias LIKE 'prioridad'";
    $result = $conexion->query($query);                
    $row = $result->fetch(PDO::FETCH_ASSOC);
    preg_match("/^enum\((.*)\)$/", $row['Type'], $matches);
    $enumValues = explode(",", $matches[1]);                    
    foreach ($enumValues as $value) {
        $cleanValue = trim($value, "'");
        $selected = ($cleanValue == $incidencia->prioridad) ? "selected" : "";
        echo "<option value='$cleanValue' $selected>$cleanValue</option>";
    }
    ?>
</select>

                    <br>
                </div>


                <input type="submit" class="btn btn-outline-success" name="modificar" value="Modificar">
                <input type="submit" class="btn btn-outline-warning" name="volver" value="Volver al inicio">

            </div>
        </form>
    </div>
</body>

</html>