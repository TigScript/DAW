<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Crear</title>
</head>

<body>
    <!--miEmpresa-->
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <span class="navbar-brand font-weight-bold">MiEmpresa</span>
        <div class="ml-auto">
            <span class="navbar-text font-weight-bold text-dark">Gestión de Incidencias</span>
        </div>
    </nav>
    <div style="text-align: center;">
        <h3 class="mb-4" style="strong">Incidencias registradas:</h3>
        <p> Rellena el siguiente formulario para registrar tu indidencia: </p>
    </div>


    <div class="container">

        <?php
        require_once('conexion.php');

        if (isset($_POST['crear'])) {

            $nombre = $_POST['nombre'];
            $titulo = $_POST['titulo'];
            $descripcion = $_POST['descripcion'];
            $archivo = $_POST['archivo'];
            $prioridad = $_POST['prioridad'];

            $sql = "INSERT INTO incidencias (nombre, titulo, descripcion, archivo, prioridad) VALUES('$nombre', '$titulo', '$descripcion', '$archivo', '$prioridad')";
            $insert = $conexion->query($sql);

            if ($insert) {
                // Redirecciona a listado.php después de la inserción
                header('Location: listado.php');
                exit(); // Asegura que el script se detenga después de redireccionar
            } else {
                echo "Error al insertar datos: " . $conexion->errorInfo()[2];
            }
        } elseif (isset($_POST['volver'])) {
            header('Location: listado.php');
            exit();
        }
        ?>

        <form method="POST">

            <div class="container">
                <div class="row">
                    <div class="col-6">
                        <label for="nombre">Nombre: </label>
                        <input type="text" class="form-control" name="nombre" id="nombre" />
                    </div>
                    <div class="col-6">
                        <label for="titulo">Título: </label>
                        <input type="text" class="form-control" name="titulo" id="titulo" />
                    </div>
                </div>

                <div class="row mb-2">
                    <div class="col-12">
                        <label for="descripcion">Descripción: </label>
                        <textarea class="form-control" name="descripcion" id="descripcion" cols="100"
                            rows="10"></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <p> Adjunta un archivo si lo deseas: </p>
                        <input type="file" class="form-control" name="archivo" id="archivo" />
                    </div>
                </div>
                <br>


                <div class="col-12">
                    <label for="prioridad">Prioridad: </label>
                    <select class="form-control" name="prioridad" id="prioridad" class="col-6">
                        <?php
                        // consulta para obtener los valores únicos de la row prioridad
                        $query = "SHOW COLUMNS FROM incidencias LIKE 'prioridad'";
                        $result = $conexion->query($query);

                        // extrae los valores enum de la definición de la row prioridad, este apartado lo he tenido que buscar ya que al ser tipo ENUM me estaba dando problemas...
                        $row = $result->fetch(PDO::FETCH_ASSOC);
                        preg_match("/^enum\((.*)\)$/", $row['Type'], $matches);
                        $enumValues = explode(",", $matches[1]);

                        // Limpia y formatea los valores ENUM
                        foreach ($enumValues as $value) {
                            $cleanValue = trim($value, "'");
                            echo "<option  value='$cleanValue'>$cleanValue</option>";
                        }
                        ?>
                    </select>
                    <br>
                </div>


                <input type="submit" class="btn btn-outline-success" name="crear" value="Enviar">
                <input type="submit" class="btn btn-outline-warning" name="volver" value="Volver al inicio">

            </div>
        </form>
    </div>
</body>

</html>