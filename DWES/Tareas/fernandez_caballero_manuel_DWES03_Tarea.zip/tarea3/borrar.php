<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Borrar</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <span class="navbar-brand font-weight-bold">MiEmpresa</span>
        <div class="ml-auto">
            <span class="navbar-text font-weight-bold text-dark">Gestión de Incidencias</span>
        </div>
    </nav>
    <div style="text-align: center;">
        <h3 class="mb-4" style="strong">Borrar registro:</h3>
        <p> ¿Está seguro de que desea borrar el registro? </p>
    </div>

    <div class="mt-2 text-center">
        <form method="post" action="">
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>">
            <input type="submit" class="btn btn-outline-success" name="volver" value="volver">
            <input type="submit" class="btn btn-danger" name="borrar" value="borrar">
        </form>
    </div>

    <?php 
    require_once('conexion.php');
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['borrar'])) {
            if (isset($_POST['id'])) {
                $id = $_POST['id'];
                $sql = "DELETE FROM incidencias WHERE id = $id";
                $borrar = $conexion->query($sql);
                $borrar->execute();
                
                // Después de borrar, redirigimos a listado.php
                header('Location: listado.php');
                exit();
            }
        } elseif (isset($_POST['volver'])) {
            header('Location: listado.php');
            exit();
        }
    }
    ?>

</body>

</html>
