<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Detalle</title>
</head>

<body>
    <!--miEmpresa-->
    <nav class="navbar navbar-expand-lg navbar-light bg-warning">
        <span class="navbar-brand font-weight-bold">MiEmpresa</span>
        <div class="ml-auto">
            <span class="navbar-text font-weight-bold text-dark">Gestión de Incidencias</span>
        </div>
    </nav>
    <br>

    <div class="container">
        <h3 class="mb-4" style="text-align: center;">Detalles de incidencia:</h3>


        <?php

        if (!isset($_GET['id'])) { //si no tiene id redirigimos atrás al usuario
            header("Location: listado.php");
        } else {
            require_once('conexion.php');

            $id = $_GET['id'];
            $sql = "SELECT * FROM incidencias WHERE id = $id";
            $result = $conexion->query($sql);
            $result->execute();
            $incidencia = $result->fetch(PDO::FETCH_OBJ);

            if ($incidencia == null) { //redirigir a listado.php cuando el codigo de la incidencia no existe
                header("Location: listado.php");
            }
        }
        ?>

        <div class="card mt-4 text-center">

            <div class="card-body">
                <p class="card-text">
                <p>
                    <span class="font-weight-bold"
                        style="background-color: orange; display: block; padding: 5px;">Nombre:</span>
                </p>
                <p>
                    <span>
                        <?php echo $incidencia->nombre; ?>
                    </span>
                </p>

                <p>
                    <span class=font-weight-bold style="background-color: orange; display: block; padding: 5px;">Título:
                    </span>
                </p>
                <p>
                    <span>
                        <?php echo $incidencia->titulo; ?>
                    </span>
                </p>
                <p>
                    <span class=font-weight-bold
                        style="background-color: orange; display: block; padding: 5px;">Descripción: </span>
                </p>
                <p> <span>
                        <?php echo $incidencia->descripcion; ?>
                    </span>

                </p>
                <p>
                    <span class=font-weight-bold
                        style="background-color: orange; display: block; padding: 5px;">Prioridad: </span>
                </p>
                <p> <span>
                        <?php echo $incidencia->prioridad; ?>
                    </span>

                </p>
                <p>
                    <span class=font-weight-bold
                        style="background-color: orange; display: block; padding: 5px;">Archivo: </span>
                </p>
                <p> <span>
                        <?php echo $incidencia->archivo; ?>
                    </span>

                </p>
                <p>
                    <span class=font-weight-bold style="background-color: orange; display: block; padding: 5px;">Estado:
                    </span>
                    <span>
                </p>
                <p>
                    <?php echo $incidencia->estado; ?>
                    </span>
                </p>
                </p>
            </div>
        </div>
    </div>

    <div class="mt-2 text-center">
        <form action="listado.php">
            <input type="submit" class="btn btn-light" value="volver">
        </form>
    </div>


</body>

</html>