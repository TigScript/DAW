<?php
include '../src/Tasks.php';
require '../src/xajax_core/xajax.inc.php';

$service = new Google_Service_Tasks($client);

$xajax = new xajax('../src/Tools.php');
$xajax->register(XAJAX_FUNCTION, 'ordenarEnvios');

$xajax->configure('javascript URI', '../src/');
//$xajax->configure('debug', false);
$xajax->processRequest();

function getListasTareas()
{
    global $service;
    $optParams = ['maxResults' => 100];
    $results = $service->tasklists->listTasklists($optParams);
    return $results;
}

function getTareas($id)
{
    global $service;
    $res1 = $service->tasks->listTasks($id);
    return $res1;
}

function createNewRepartoList($fecha)
{
    global $service;

    // Verificar si ya existe una lista de tareas para la fecha proporcionada
    $existingLists = getListasTareas();
    foreach ($existingLists->getItems() as $existingList) {
        if ($existingList->getTitle() === "Repartos $fecha") {
            return "Ya existe una lista de reparto para esta fecha.";
        }
    }

    // Crear una nueva lista de tareas para la fecha proporcionada
    $title = "Repartos $fecha";
    $opciones = ["title" => $title];
    $taskList = new Google_Service_Tasks_TaskList($opciones);
    try {
        $service->tasklists->insert($taskList);
        return "Lista de reparto creada exitosamente para la fecha $fecha.";
    } catch (Google_Exception $ex) {
        return "Error al crear una lista de reparto: " . $ex->getMessage();
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha = $_POST['fecha'];

    // Verificar si la fecha introducida no es inferior a la fecha actual
    $fechaActual = date("Y-m-d");
    if ($fecha < $fechaActual) {
        echo "La fecha no puede ser inferior a la fecha actual.";
    } else {
        // Crear una nueva lista de reparto
        echo createNewRepartoList($fecha);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
          integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Repartos</title>
    <?php $xajax->printJavascript(); ?>
    <script src="funciones.js"></script>
</head>

<body style="background:#00bfa5;">
<h4 class="text-center mt-3">Gestión de Pedidos</h4>
<div class="container mt-4" style='width:80rem;'>
    <form action='<?php echo $_SERVER['PHP_SELF'] ?>' method='post'>
        <div class="row">
            <div class="col-md-4 mb-2">
                <button type='submit' class="btn btn-info"><i class='fas fa-plus mr-1'></i>Nueva Lista de Reparto</button>
            </div>
            <div class="col-md-4">
                <input type="date" class="form-control" id="fecha" name="fecha" required>
            </div>
        </div>
    </form>
    <?php
    $listas = getListasTareas();
    foreach ($listas->getItems() as $lista) {
        if ($lista->getTitle() == "My Tasks" || $lista->getTitle() == "Mis tareas") continue;
        echo "<table class='table mt-2' id='{$lista->getId()}'>\n";
        echo "<thead class='bg-secondary'>\n";
        echo "<tr>\n";
        echo "<th scope='col' style='width:42rem;'>{$lista->getTitle()}</th>\n";
        echo "<th scope='col' class='text-right'>\n";
        echo "<a href='envio.php?id={$lista->getId()}' class='btn btn-info mr-2 btn-sm'><i class='fas fa-plus mr-1'></i>Nuevo</a>\n";
        echo "<button class='btn btn-success mr-2 btn-sm' onclick=\"ordenarEnvios('{$lista->getId()}')\"><i class='fas fa-sort mr-1'></i>Ordenar</button>\n";
        echo "<button class='btn btn-secondary btn-sm' onclick=\"hideOrder()\"><i class='fas fa-eye-slash mr-1'></i>Ocultar Orden</button>\n";
        echo "<a href='repartos.php?action=blt&idlt={$lista->getId()}' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Borrar Lista?')\"><i class='fas fa-trash mr-1'></i>Borrar</a>\n";
        echo "</th></tr>\n";
        echo "</thead>\n";
        echo "<tbody style='font-size:0.8rem'>\n";
        $tareas = getTareas($lista->getId());
        foreach ($tareas->getItems() as $tarea) {
            echo "<tr>\n";
            echo "<th scope='row'>{$tarea->getTitle()} ({$tarea->getNotes()})\n";
            echo "<input type='hidden' value='{$tarea->getNotes()}'></th>\n";
            echo "<th scope='row' class='text-right'>\n<a href='repartos.php?action=bt&idlt={$lista->getId()}&idt={$tarea->getId()}' class='btn btn-danger btn-sm' onclick=\"return confirm('¿Borrar Tarea?')\">";
            echo "<i class='fas fa-trash mr-1'></i>Borrar</a>\n";
            echo "<a href='#' onclick='abrirMaps();' class='btn btn-info ml-2 btn-sm'><i class='fas fa-map mr-1'></i>Mapa</a>\n</th>\n";
            echo "</tr>\n";
        }
        echo "</tbody>\n";
        echo "</table>\n";
        if (isset($_SESSION[$lista->getId()])) {
            echo "<div class='container mt-2 mb-2' style='font-size:0.8rem'>";
            echo "<ul class='list-group'>";
            foreach ($_SESSION[$lista->getId()] as $k => $v) {
                echo "<li class='list-group-item list-group-item-info'>" . ($k + 1) . ".- " . $v . "</li>";
            }
            echo "</div>";
        }
    }
    ?>
</div>
<script>
    // Función para ocultar la lista de envíos ordenados
    function hideOrder() {
        var orderedListContainer = document.querySelector(".container"); // Cambia el selector si es necesario
        orderedListContainer.style.display = "none"; // Oculta el contenedor
    }
</script>
</body>

</html>