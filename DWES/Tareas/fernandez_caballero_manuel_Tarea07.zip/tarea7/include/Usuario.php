<?php

// requiero el archivo de conexión
require 'Conexion.php';

// creo la clase Usuario que extiende de Conexion
class Usuario extends Conexion
{
    // propiedades privadas para usuario y contraseña
    private $usuario;
    private $pass;

    // constructor que llama al constructor de la clase padre
    public function __construct()
    {
        parent::__construct();
    }

    // método para validar la existencia de un usuario
    public function isValido($u, $p)
    {
        // se realiza un hash de la contraseña
        $pass1 = hash('sha256', $p);

        // se prepara la consulta SQL
        $consulta = "select * from usuarios where usuario=:u AND pass=:p";
        $stmt = Conexion::$conexion->prepare($consulta);

        try {
            // se ejecuta la consulta con los parámetros proporcionados
            $stmt->execute([
                ':u' => $u,
                ':p' => $pass1
            ]);
        } catch (\PDOException $ex) {
            // en caso de error, se muestra un mensaje y se termina la ejecución
            die("Error al consultar usuario: " . $ex->getMessage());
        }

        // se obtiene el número de filas afectadas por la consulta
        $filas = $stmt->rowCount();
        
        // si no se encuentra ningún registro, se devuelve false; de lo contrario, true
        if ($filas == 0) return false;
        return true;
    }
}
