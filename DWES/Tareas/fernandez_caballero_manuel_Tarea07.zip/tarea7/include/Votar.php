<?php
// incluyo los archivos necesarios...
require 'Voto.php';
require_once 'xajax_core/xajax.inc.php';

// Creo una nueva instancia de xajax
$xjax = new xajax();

// Se registra la función 'miVoto' con xajax
$xjax->register(XAJAX_FUNCTION, 'miVoto');
function miVoto($cantidad, $idPr, $idUs)
{
    $resp = new xajaxResponse();  // Se crea una nueva respuesta xajax
    $voto = new Voto();       // Se crea un objeto de la clase 'Voto'

    // Verifico si el voto es válido
    if (!$voto->isValido($idPr, $idUs)) {
        $resp->setReturnValue(false);
    } else {
        // si es válido, se inserta el voto en la base de datos
        $voto->insertarVoto($cantidad, $idPr, $idUs);
        // establezco el valor de retorno de la respuesta como verdadero
        $resp->setReturnValue(true);
    }
    // devuelvo la respuesta
    return $resp;
}

// registro la función 'pintarEstrellas' con xajax
$xjax->register(XAJAX_FUNCTION, 'pintarEstrellas');
function pintarEstrellas()
{
    // creo una nueva respuesta xajax
    $resp = new xajaxResponse();
    // creo un objeto de la clase 'Voto'
    $voto = new Voto();
    // obtengolos datos de valoración de los productos
    $resultado = $voto->pintarEstrellas();

    // recorro el resultado obtenido
    foreach ($resultado as $key => $value) {
        $id = $value['id'];
        $mediaVotos = $value['mediaVotos'];
        $numVotos = $value['numVotos'];
        $innerHTML = '';
        // se verifican las valoraciones
        if ($numVotos == 0) {
            $innerHTML = 'Sin valoración';
        } else {
            // genero el HTML para mostrar las estrellas correspondientes a la valoración media
            $innerHTML .= '<p>' . $numVotos . ' valoraciones: ';
            if (floor($mediaVotos) != $mediaVotos) { 
                for ($i = 0; $i < $mediaVotos - 1; $i++) {
                    $innerHTML .= '<i class="fas fa-star"></i>'; //añadimos una estreaña
                }
                $decimal = $mediaVotos - floor($mediaVotos);
                if ($decimal >= 0.5) {
                    $innerHTML .= '<i class="fas fa-star-half"></i>'; //añadimos media estrella
                }
            } else {
                for ($i = 0; $i < $mediaVotos; $i++) { 
                    $innerHTML .= '<i class="fas fa-star"></i>';
                }
            }

            $innerHTML .= '</p>'; //utilizamos un p para que todo vaya en la misma linea
        }
        // Asigno el HTML generado a los elementos correspondientes en la página web
        $resp->assign("votos_" . $id, "innerHTML", $innerHTML);
    }

    // establezco el valor de retorno de la respuesta como verdadero
    $resp->setReturnValue(true);
    // se libera la memoria
    $voto = null;
    // y devuelvo la respuesta
    return $resp;
}

// se requestea la  solicitud xajax
$xjax->processRequest();
