<?php

require 'Conexion.php'; //requerimos como siempre de conexion... 
class Voto extends Conexion  //hereda de conexion
{

    public function __construct() //constructor de la clase
    {
        parent::__construct(); //llamada al constructor de la clase padre
    }

    public function isValido($idPr, $idUs)// Función para verificar si un voto es válido
    {
        $consulta = "select * from votos where idPr=:idPr AND idUs=:idUs"; //consulta para verificar la existencia de un voto
        $stmt = Conexion::$conexion->prepare($consulta); //preparacion de la xonsulta
        try {
            $stmt->execute([
                ':idPr' => $idPr,
                ':idUs' => $idUs
            ]); //ejecuta la consulta
        } catch (\PDOException $ex) { //manejo de errores
            die("Error al consultar usuario: " . $ex->getMessage());
        }
        $filas=$stmt->rowCount(); //obtenemos el numero de filas resultantes
        if ($filas > 0) return false; //si hay almenos una, el voto no es válido
        return true; //si no hay filas, el voto es valido
    }

    public function insertarVoto($cantidad, $idPr, $idUs) {  // Función para insertar un voto en la base de datos, usamos la misma estructura
        $insert = "INSERT INTO votos (cantidad, idPr, idUs) VALUES (:cantidad,:idPr,:idUs)";
        $stmt = Conexion::$conexion->prepare($insert);
        try {
            $stmt->execute([
                ':cantidad' => $cantidad,
                ':idPr' => $idPr,
                ':idUs' => $idUs
            ]);
        } catch (\PDOException $ex) {
            die("Error al consultar usuario: " . $ex->getMessage());
        }
        $filas=$stmt->rowCount();
        if ($filas == 0) return false;
        return true;
    }

    function pintarEstrellas() {  
        $consulta = "select p.id, "; // Función para obtener la media de votos y el número de votos por producto
        $consulta .= "IFNULL(sum(cantidad) / count(*), 0) as mediaVotos, "; //calculamos la media de votos de cada producto 
        $consulta .= "count(v.idPr) as numVotos ";//Cuenta el número de votos para cada producto
        $consulta .= "from votos v right join productos p ";
        $consulta .= "on v.idPr = p.id group by p.id"; // Función para obtener la media de votos y el número de votos por producto
        $stmt = Conexion::$conexion->prepare($consulta); //preparamos la consulta de la misma manera con los bloques try catch para el manejo de errores
        try {
            $stmt->execute();
        } catch (\PDOException $ex) {
            die("Error al consultar usuario: " . $ex->getMessage());
        }
        $data = array(); //iniciamos una rray para almacenar los resultados
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($data, $row); // almacena cada fila de resultado en el array
        }
        return $data;
    }

}