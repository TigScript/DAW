<?php

// Clase para la conexión a la base de datos
class Conexion
{
    // Propiedad protegida para almacenar la conexión
    protected static $conexion;

    // Constructor de la clase
    public function __construct()
    {
        // Si la conexión está vacía, se crea una nueva
        if (self::$conexion == null) {
            self::crearConexion();
        }
    }

    // Método estático para crear la conexión
    public static function crearConexion()
    {
// Datos de conexión a la base de datos... como he tenido que reinstalar XAMP he perdido las bases de datos anteriores y he creado una nueva llamada proyecto7
// con el siguiente usuario y permisos:
//   create user gestorT7@'localhost' identified by "secreto";
// grant all on proyectoT7.* to gestorT7@'localhost';
        $user = "gestorT7";
        $pass = "secreto";
        $base = 'proyectot7';
        $dsn = "mysql:host=localhost;dbname=$base;charset=utf8mb4";
        
        try {
            // Se crea una nueva instancia de PDO para establecer la conexión
            self::$conexion = new PDO($dsn, $user, $pass);
            // Se configura el modo de error
            self::$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $ex) {
            // En caso de error, se muestra un mensaje y se termina la ejecución
            die("Error en la conexión: mensaje: " . $ex->getMessage());
        }
    }
}
