<?php
require 'Usuario.php'; // Incluyo el archivo que contiene la clase Usuario
require_once 'xajax_core/xajax.inc.php'; //incluido en los archivos de xajax_master del temario -> https://github.com/Xajax/Xajax

$xjax=new xajax(); //creacion de instancia xajax
$xjax->register(XAJAX_FUNCTION, 'vUsuario'); 
$xjax->processRequest(); // Proceso la solicitud xajax entrante
function vUsuario($u, $p){ //defino la funcion vUsuario pasandole los valores definidos de usuario y contraseña

        $resp=new xajaxResponse(); // Crea una nueva respuesta xajax
        if(strlen($u)==0 || strlen($p)==0){ //verifico que la cadena del usuario o la contraseña estan vacias, y si es asi devuelvo false
            $resp->setReturnValue(false);
        }
        else {
            $usuario = new Usuario(); //si el usuario es valido inicio sesion  y configuro el valor de retorno de la respuesta como verdadero
            if (!$usuario->isValido($u, $p)) {
                $resp->setReturnValue(false);
            } else {
                session_start();
                $_SESSION['usu'] = $u;
                $resp->setReturnValue(true);
            }
            $usuario = null; // Libera la memoria asignada a la instancia de Usuario
        } 
        return $resp; // Devuelve la respuesta xajax
    } 
