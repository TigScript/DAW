<?php
// inicio de la sesión php para manejar variables de sesión
session_start();

// verifico si la variable de sesión 'usu' está establecida
if(isset($_SESSION['usu'])) {
    // si está establecida, la elimino
    unset($_SESSION['usu']);
}

// redirijo al usuario a la página de inicio de sesión 'login.php'
header('Location: login.php');

