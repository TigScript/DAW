function envForm() {
    var usu = document.getElementById("usu").value; //obtenemos los valores del usuario
    var pass = document.getElementById('pass').value; //obtenemos los valores de la contraseña
    var res = xajax.request({xjxfun: 'vUsuario'}, {mode: 'synchronous', parameters: [usu, pass]}); //petición php de modo sincrono con el usuario y la pass del formulario
    if(res==false) alert("Credenciales Erróneas !!!");
    return res;
}

function envFormVoto(form){
    var res = xajax.request({xjxfun: 'miVoto'}, {mode: 'synchronous', parameters: [form['cantidad'], form['idPr'], form['idUs']]});
    if(res==false){
        alert("No se puede votar dos veces el mismo producto!!!");
    }else{
        xajax.request({xjxfun: 'pintarEstrellas'}, {mode: 'synchronous', parameters: []});
    } 
    return res;
}