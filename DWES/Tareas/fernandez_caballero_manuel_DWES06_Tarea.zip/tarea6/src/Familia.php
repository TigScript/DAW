<?php

    namespace Clases;
    require_once 'Conexion.php';
//nos conectamos a la base de datos y ejecutamos una consulta para obtener todas las filas de la tabla familias
use Conexion;
use PDO;
    use PDOException;

class Familia{
    

    public function getFamilias(){

        $aux = new Conexion;
        $conexion = $aux->conectar();
        $consulta = "SELECT * FROM familias";
        $familias = $conexion->prepare($consulta);
        try{
            $familias->execute();
        } catch(PDOException $e){
            die("Error al obtener datos: ".$e->getMessage());
        }
        return $familias->fetchAll(PDO::FETCH_OBJ);
    }
}