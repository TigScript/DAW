<?php
    namespace Clases;
    
    require_once 'Producto.php';
    require_once 'Stock.php';
    require_once 'Familia.php';


    /**Uso el arroba con soap y param como se indicar en los apuntes, ya que si no no obtendremos los datos si no especificamos el tipo de dato
    */

class Operaciones{
/**
    * @soap
    * @param integer $codigo
    * @return float
    */

function getPvp($codigo){
    // Se obtiene la lista de productos utilizando el método getProductos de la clase Producto
    $listaProductos = (new Producto)->getProductos();
    $precio=0;
      // Se busca el producto con el código proporcionado en la lista de productos y se obtiene su precio
    foreach($listaProductos as $prod){
        if($prod->id == $codigo){
            $precio= $prod->pvp;
        }
    }
    //devolvemos el precio
    return $precio;
    
}

/**
    * @soap
    * @param integer $producto
    * @param integer $tienda
    * @return integer
    */
function getStock($producto, $tienda){
    //hacemos lo mismo 
    $listaStock = (new Stock)->getStocks();
     // Se busca el stock del producto en la tienda especificada en la lista de stocks
    foreach($listaStock as $lista){
        if($lista->producto == $producto && $lista->tienda == $tienda){
            return $lista->unidades;
        }
    }
}

/**
    * @soap
    * @return array 
    */
function getFamilias(){
    $listaFamilias = (new Familia)->getFamilias();
    $familias = [];
    foreach($listaFamilias as $lista){
        array_push($familias, $lista->nombre);
    }
    return $familias;
}

/**
    * @soap
    * @param string $familia
    * @return array 
    */
function getProductosFamilia($familia){
    $listaProductos = (new Producto)->getProductos();
    $lista = [];
     // Se obtienen los nombres de las familias y se agregan a la lista, indicamos que es un array como se pide en la tarea
    foreach($listaProductos as $prod){
        if($prod->familia == $familia){
            array_push($lista, $prod->id);
        }
    }
    return $lista;
}

}

