<?php

    namespace Clases;
    require_once 'Conexion.php';
//nos conectamos a la base de datos y ejecutamos una consulta para obtener todas las filas de la tabla productos
use Conexion;
use PDO;
    use PDOException;

class Producto{
    

    public function getProductos(){

        $aux = new Conexion;
        $conexion = $aux->conectar();
        $consulta = "SELECT * FROM productos";
        $productos = $conexion->prepare($consulta);
        try{
            $productos->execute();
        } catch(PDOException $e){
            die("Error al obtener datos: ".$e->getMessage());
        }
        return $productos->fetchAll(PDO::FETCH_OBJ);
    }
}