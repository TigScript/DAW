<?php

    namespace Clases;
    require_once 'Conexion.php';
//nos conectamos a la base de datos y ejecutamos una consulta para obtener todas las filas de la tabla stock
use Conexion;
use PDO;
    use PDOException;

class Stock{
    

    public function getStocks(){

        $aux = new Conexion;
        $conexion = $aux->conectar();
        $consulta = "SELECT * FROM stocks";
        $stocks = $conexion->prepare($consulta);
        try{
            $stocks->execute();
        } catch(PDOException $e){
            die("Error al obtener datos: ".$e->getMessage());
        }
        return $stocks->fetchAll(PDO::FETCH_OBJ);
    }
}