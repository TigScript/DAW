<?php
//requerimos de Operaciones
    require_once '../src/Operaciones.php';
//indicamos uri del servidor soap
    $uri="http://localhost/tarea6/servidorSoap";
    //se crea una instancia del servidor soap, esta vez indicando un archivo wsdl 
    try{
    $server= new SoapServer('servicio.wsdl',array('uri'=>$uri));
    $server->setClass('Clases\\Operaciones');
    $server->handle();
    }catch(SoapFault $f){
        die("error en server: ". $f->getMessage());
    }
?>