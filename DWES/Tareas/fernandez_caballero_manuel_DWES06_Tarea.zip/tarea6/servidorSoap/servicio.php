<?php

    // Uso require once como en los otros archivos para acceder a operaciones
    require_once '../src/Operaciones.php';

    // defino la uri del servidor soap y lo guardo en una variable
    $uri = "http://localhost/tarea6/servidorSoap";

    try {
        // como en este apartado no se pide el wsdl, dejamos "null"
        $server = new SoapServer(null, array('uri' => $uri));

        // Establezco la clase 'Operaciones' como la clase que manejará las operaciones SOAP
        $server->setClass('Clases\\Operaciones');

        // Para iniviar y "manejar" las peticiones entrantes del servidor
        $server->handle();

    } catch (SoapFault $f) {
        // En caso de un fallo SOAP, mostramos mensaje de error
        die("Error en el servidor: " . $f->getMessage());
    }
?>
