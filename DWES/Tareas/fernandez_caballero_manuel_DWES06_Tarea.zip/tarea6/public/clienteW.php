<?php
//namespace Clases;
header('Content-Type: text/html; charset=UTF-8');

$url="http://localhost/tarea6/servidorSoap/servicio.wsdl";
try{
  
    
  $cliente = new SoapClient($url, ['encoding'=>'UTF8','location' => 'http://localhost/tarea6/servidorSoap/servicioW.php',
   'uri' => 'http://localhost/tarea6/servidorSoap', 'trace' => true]);
   //$cliente = new SoapClient($url);
    }catch(SoapFault $ex){
        echo "Error: ".$ex->getMessage();
}
//var_dump($cliente->__getFunctions());


print "<h1>CLIENTE.PHP</h1>";
print "Precio: ".$cliente->getPvp(1);
print "<br><hr>";
print "Cantidad: ".$cliente->getStock(1, 1);
print "<br><hr>";
print "Lista de familias: <br>";
print_r($cliente->getFamilias());
print "<br><hr>";
print "Productos de la familia NETBOK: <br>";
print_r($cliente->getProductosFamilia("NETBOK"));
