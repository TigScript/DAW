<?php
//namespace Clases;
//require_once '../src/Operaciones.php';
header('Content-Type: text/html; charset=UTF-8');

try{
    //se crea una instancia del cliente SOAP y manejamos la excepcion en caso de error
    $cliente = new SoapClient(null, ['encoding'=>'UTF8','location' => 'http://localhost/tarea6/servidorSoap/servicio.php',
        'uri' => 'http://localhost/tarea6/servidorSoap', 'trace' => true]);
    }catch(SoapFault $ex){
        echo "Error: ".$ex->getMessage();
}


//llamamos a los metodos y lo imprimimos en pantalla para testear el correcto funcionamiento de las funciones
print "<h1>CLIENTE.PHP</h1>";
print "Precio: ".$cliente->getPvp(1);
print "<br><hr>";
print "Cantidad: ".$cliente->getStock(1, 1);
print "<br><hr>";
print "Lista de familias: <br>";
print_r($cliente->getFamilias());
print "<br><hr>";
print "Productos de la familia NETBOK: <br>";
print_r($cliente->getProductosFamilia("NETBOK"));