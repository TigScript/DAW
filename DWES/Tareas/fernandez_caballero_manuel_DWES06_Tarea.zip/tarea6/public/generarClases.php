<?php
//requerimos del autoloading de composer, utilizamos la clase generator para generar clases... Por más que lo intente no consigo que funcione, la librería está deprecated
require '../vendor/autoload.php';
use Wsdl2PhpGenerator\Generator;
use Wsdl2PhpGenerator\Config;

$generator = new Generator();
$generator->generate(
    new Config([
        'inputFile' => 'http://localhost/tarea6/servidorSoap/servicioW.php?WSDL',
        'outputDir' => '../src',
        'namespaceName' => 'Clases'
     ])
);
?>
