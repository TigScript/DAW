<?php
//Defino el namespace para la clase operaciones
namespace Clases;


//usamos los require necesarios
require '../vendor/autoload.php';
require_once '../src/Operaciones.php';

// Se utiliza la clase PHPClass2WSDL de la biblioteca PHP2WSDL para generar un WSDL para la clase Operaciones
use PHP2WSDL\PHPClass2WSDL;

// Se crea una instancia del generador WSDL y se genera el WSDL
$class = "Clases\\Operaciones";
$uri = 'http://localhost/tarea6/servidorSoap/servidorW.php';
$wsdlGenerator = new PHPClass2WSDL($class, $uri);
$wsdlGenerator->generateWSDL(true);
// Como se indica en la tarea, se guarda el WSDL generado en la carpeta '../servidorSoap/' con el nombre 'servicio.wsdl'
$fichero = $wsdlGenerator->save('../servidorSoap/servicio.wsdl');
?>
