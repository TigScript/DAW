<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mostrar</title>
    <!-- link de bootstrap de https://getbootstrap.com/docs/5.3/getting-started/introduction/#quick-start -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body class="bg-secondary"> <!-- bg-secondary para el fondo gris de la tarea-->
    <?php
    session_start(); //inicio/reanudo la sesión
    if (isset($_POST['establecer'])) { //si establecer está seteado redirigimos a preferencias.php al pulsar
        header('Location: preferencias.php');


    } else if (isset($_POST['borrar'])) { //si borrar esta seteado
        if (!isset($_SESSION['idioma']) && !isset($_SESSION['perfil']) && !isset($_SESSION['zona'])) {
            $error = true; //si no estan seteados lanzamos el mensaje de error configurado más adelante
    
        } else { //si están los tres configurados:
            unset($_SESSION['idioma']); //unset para 'desetearlo', tambien podría igualar el valor a null
            unset($_SESSION['perfil']);
            unset($_SESSION['zona']);

            echo ' <p class="alert alert-success" role="alert">Configuración borrada con éxito</p>'; // y aprovecho para poner aquí el mensaje de cuando se borran las configuraciones
        }
    }
    ?>
    <div class="container bg-success mt-3 w-50 p-3 text-light">
        <!-- bg-success para el fondo verde de la tarea, margin top de 3, padding de 3, ancho del 50% y texto en blanco-->
        <div class="row">
            <!-- una fila para el titulo y el icono, en bootstrap las medidas van del 1 al 12 siendo un 12 el 100% -->
            <h4> <i class="fa-solid fa-user-gear"></i> Preferencias</h4>
            <div class="col-12">
            </div>
        </div>

        <div class="row">
            <div class="col-12">


                <?php
                if (isset($error)) {
                    ?>
                    <!-- En lugar de un mensaje en rojo como se indica en la tarea utilizo una alerta en rojo de bootstrap -->
                    <p class="alert alert-danger" role="alert">Debes configurar las preferencias para poder borrarlas</p>
                    <?php
                }
                ?>

                <p><span class="fw-bold">Idioma: </span> <!-- fw-bold para la negrita-->
                    <?php echo isset($_SESSION['idioma']) ? $_SESSION['idioma'] : 'Idioma no seleccionado' ?>
                </p>
                <p><span class="fw-bold">Perfil Público: </span>
                    <?php echo isset($_SESSION['perfil']) ? $_SESSION['perfil'] : 'Perfil no seleccionado' ?>
                </p>
                <p><span class="fw-bold">Zona horaria: </span>
                    <?php echo isset($_SESSION['zona']) ? $_SESSION['zona'] : 'Zona horaria no seleccionada' ?>
                </p>

                <form method="POST">
                    <button type="submit" class="btn btn-primary" name="establecer">Establecer</button>
                    <!-- utilizo botones de bootstrap... -->
                    <button type="submit" class="btn btn-danger" name="borrar">Borrar</button>

                </form>
            </div>
        </div>

    </div>

    <!-- me registro en fontawesome y linkeo -->
    <script src="https://kit.fontawesome.com/ae0b9648b4.js" crossorigin="anonymous"></script>
</body>

</html>