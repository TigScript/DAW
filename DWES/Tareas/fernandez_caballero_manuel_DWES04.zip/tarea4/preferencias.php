<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preferencias</title>
    <!-- link de bootstrap de https://getbootstrap.com/docs/5.3/getting-started/introduction/#quick-start -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body class="bg-secondary"> <!-- bg-secondary para el fondo gris de la tarea-->


    <?php
    session_start(); //inicio de la sesión
    
    if (isset($_POST['mostrar'])) { //redirección a mostrar.php si mostrar está seteado
        header('Location: mostrar.php');
    } else if (isset($_POST['establecer'])) { //declaración y almacenamiento de los valores de las variables, el booleano lo usaré para indicar con un mensaje cuando se han guardado las preferencias
    
        $_SESSION['idioma'] = $_POST['idioma'];
        $_SESSION['perfil'] = $_POST['perfil'];
        $_SESSION['zona'] = $_POST['zona'];
        $preferencias = true;

    }


    ?>

    <div class="container bg-white mt-3 w-50">
        <!-- fondo blanco, margin top de 3 unidades, width del 50% -->
        <div class="row">
            <div class="col-12 p-2 ps-3 bg-light">
                <h2>Preferencias Usuario</h2>
            </div>
        </div>

        <div class="row pt-2 pb-2"> <!-- padding por arriba y por abajo de dos unidades -->
            <div class="col-12 ">
                <form method="POST"> 

                    <?php
                    if (isset($preferencias)) {
                        ?>
                        <!-- text primary para el color azul del parrafo -->
                        <p class="text-primary">Preferencias de usuario guardadas</p>
                        <?php
                    }

                    ?>
<!--Para el formulario he utilizado input-group mb-3 de Custom forms: https://getbootstrap.com/docs/5.0/forms/input-group/ y lo he adaptado  -->
                    <span>Idioma</span>
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="idioma">
                            <!-- Me ha costado encontrar este icono en bootstrap... -->
                            <i class="fa-solid fa-language"></i>
                        </label>

                        <select class="form-select" id="idioma" name="idioma">
                            <option value="ingles" <?php echo isset($_SESSION['idioma']) && $_SESSION['idioma'] == 'ingles' ? 'selected' : null ?>>Inglés</option>
                            <!-- Usando un if ternario para reducir espacio, uso un bloque php para comprobar si está seteado, si es igual a el que estamos mirando, selected, y si no, null-->
                            <option value="español" <?php echo isset($_SESSION['idioma']) && $_SESSION['idioma'] == 'español' ? 'selected' : null ?>>Español</option>
                        </select>
                    </div>

                    <span>Perfil Público</span>
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="inputGroupSelect01">
                            <i class="fa-solid fa-users"></i>
                        </label>
                        <select class="form-select" name="perfil" id="perfil">
                            <option value="si" <?php echo isset($_SESSION['perfil']) && $_SESSION['perfil'] == 'si' ? 'selected' : null ?>>Sí</option>
                            <option value="no" <?php echo isset($_SESSION['perfil']) && $_SESSION['perfil'] == 'no' ? 'selected' : null ?>>No</option>
                        </select>
                    </div>


                    <span>Zona Horaria</span>
                    <div class="input-group mb-3">
                        <label class="input-group-text" for="zona">
                            <i class="fa-solid fa-clock"></i>

                        </label>
                        <select class="form-select" name="zona" id="zona">
                            <option value="gmt-2" <?php echo isset($_SESSION['zona']) && $_SESSION['zona'] == 'gmt-2' ? 'selected' : null ?>>GMT-2</option>
                            <option value="gmt-1" <?php echo isset($_SESSION['zona']) && $_SESSION['zona'] == 'gmt-1' ? 'selected' : null ?>>GMT-1</option>
                            <option value="gmt" <?php echo isset($_SESSION['zona']) && $_SESSION['zona'] == 'gmt' ? 'selected' : null ?>>
                                GMT</option>
                            <option value="gmt+1" <?php echo isset($_SESSION['zona']) && $_SESSION['zona'] == 'gmt+1' ? 'selected' : null ?>>GMT+1</option>
                            <option value="gmt+2" <?php echo isset($_SESSION['zona']) && $_SESSION['zona'] == 'gmt+2' ? 'selected' : null ?>>GMT+2</option>
                        </select>
                    </div>



                    <div class="row">

                        <div class="col-6"> <!--6 equivale al 50% ya que va del 1 al 12 -->
                            <button class="btn btn-primary" type="submit" name="mostrar">Mostrar Preferencias</button>
                        </div>

                        <div class="col-6 text-end"> <!--text end para ajustar a la derecha-->
                            <button class="btn btn-danger" type="submit" name="establecer">Establecer
                                Preferencias</button>
                        </div>

                    </div>



                </form>
            </div>
        </div>







    </div>







    <!-- me registro en fontawesome y linkeo -->
    <script src="https://kit.fontawesome.com/ae0b9648b4.js" crossorigin="anonymous"></script>
</body>

</html>