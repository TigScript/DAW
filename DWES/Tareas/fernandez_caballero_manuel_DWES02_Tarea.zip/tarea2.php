<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tarea 2</title>
    <link rel="stylesheet" href="estilos.css">
</head>

<body>

    <h4>Agenda</h4>

    <?php
    session_start(); // para iniciar o reanudar una sesión en PHP almacenar y acceder a variables de sesión en el script.
    
    if (!isset($_SESSION['contactos'])) { // si contactos no esta definido, se crea un array vacio de contactos, para contar siempre con un array
        $_SESSION['contactos'] = array();
    }



    $alerta = ""; //Si el nombre está vacío, se mostrará una advertencia.
    if (isset($_POST['aniadir'])) {
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];

        if (empty($nombre)) {
            $alerta = "El nombre es un campo obligatorio";
        } else if (!isset($_SESSION['contactos'][$nombre]) && empty($telefono)) {
            $alerta = "El telefono es un campo obligatorio";
        } else if (isset($_SESSION['contactos'][$nombre]) && empty($telefono)) {
            $alerta = "El contacto ha sido borrado";
            unset($_SESSION['contactos'][$nombre]); //borrar contacto
    

        } else {
            $contacto = array(
                "nombre" => $nombre,
                "telefono" => $telefono
            );


            if (isset($_SESSION['contactos'][$nombre])) {
                $alerta = "El número de teléfono  sido actualizado"; //Si el nombre que se introdujo no existe en la agenda, y el número de teléfono no está vacío, se añadirá a la agenda.
            } else {
                $alerta = "El contacto ha sido añadido"; //Si el nombre que se introdujo ya existe en la agenda y se indica un número de teléfono, se sustituirá el número de teléfono anterior.
    
            }

            $_SESSION['contactos'][$nombre] = $contacto;
        }
    }


    if (isset($_GET['vaciar'])) {
        $alerta = "Todos los contactos han sido vaciados";

        $_SESSION['contactos'] = array();

    }

    if (!empty($alerta)) { //Si el nombre está vacío, se mostrará una advertencia.
        ?>
        <p class="alerta">
            <?php echo $alerta; ?>
        </p>
        <?php

    }

    ?>

    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

        <?php
        if (count($_SESSION['contactos']) > 0) { //Para cuando haya al menos un contacto
            ?>
            <fieldset>
                <legend>Datos Agenda</legend>
                <table>
                    <?php
                    foreach ($_SESSION['contactos'] as $key => $value) {
                        ?>
                        <tr>
                            <td>
                                <?php echo $value['nombre']; ?>
                            </td>
                            <td>
                                <?php echo $value['telefono']; ?>
                            </td>
                        </tr>
                        <?php

                    }
                    ?>
                </table>
            </fieldset>
            <?php
        }
        ?>


        <fieldset>
            <legend>Nuevo Contacto</legend>
            <table>
                <tr>
                    <td>
                        <label for="nombre">Nombre: </label>
                    </td>
                    <td>
                        <input type="text" name="nombre" id="nombre" placeholder="Ingrese el nombre ">
                    </td>
                </tr>

                <tr>
                    <td>
                    <label for="telefono">Teléfono: </label>
                    </td>
                    <td>
                    <input type="text" name="telefono" id="telefono" placeholder="Ingrese el teléfono "> <!-- podria ser tipo 'tel' para el teléfono -->
                    </td>
                </tr>
            </table>


           
           

            <button type="submit" name="aniadir">Añadir Contactos</button>
            <button type="reset">Limpiar Campos</button>

        </fieldset>

    </form>

    <?php
    if (count($_SESSION['contactos']) > 0) { //Para cuando haya al menos un contacto
        ?>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="GET">
            <fieldset>
                <legend>Vaciar Agenda</legend>
          
            <button type="submit" name="vaciar" value="1">Vaciar</button>
            </fieldset>
        </form>
        <?php

    }

    ?>

</body>

</html>