/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea4;

import javax.swing.JOptionPane;

/**
 *
 * @author manu_
 */
public class Supuesto3 {
    public static void main(String[] args) {
        int capital =Integer.parseInt(JOptionPane.showInputDialog("Introduzca su capital: "));
        int porcentaje =Integer.parseInt(JOptionPane.showInputDialog("Introduzca el porcentaje del banco: "));
        int beneficio_mensual= (porcentaje*capital)/100;
        System.out.println("El beneficio mensual es de " + beneficio_mensual + "€");
        System.out.println("El beneficio anual es de " + beneficio_mensual*12 + "€");
        System.out.println("Al cabo de un año tendrías" + (beneficio_mensual*12 + capital) + "€");
    }
    
}
