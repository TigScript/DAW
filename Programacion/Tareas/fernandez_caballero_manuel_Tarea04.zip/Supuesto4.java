/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea4;

import javax.swing.JOptionPane;


/**
 *
 * @author manu_
 */
public class Supuesto4 {
    public static void main(String[] args) {
        int temperatura =Integer.parseInt(JOptionPane.showInputDialog("Introduce la temperatura: "));
        if(temperatura>30){
            System.out.println("El deporte apropiado es natación");
        }
        else  if(temperatura>15 && temperatura<=30){
            System.out.println("El deporte apropiado es golf");
        }
        else  if(temperatura>5 && temperatura<=15){
            System.out.println("El deporte apropiado es tenis");
        }
        else  if(temperatura>-10 && temperatura<=5){
            System.out.println("El deporte apropiado es sky");
        }
        else  {
            System.out.println("El deporte apropiado es damas");
        }
       
         
         }
        
    }
    

