/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea4;

/**
 *
 * @author manu_
 */

import javax.swing.JOptionPane;
public class Supuesto5 {
    public static void main(String[] args) {
        
        String clave="eureka";
        String contraseña="";
        
        while (clave.equals(contraseña)==false){
            
           contraseña=JOptionPane.showInputDialog("Introduce la contraseña: ");
           
           if (clave.equals(contraseña)==false){               
                   System.out.println("No has acertado, inténtalo de nuevo.");
            
        }
        
    }
        System.out.println("¡Eureka! Contraseña correcta");
    }
}

