/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tarea4;
import javax.swing.JOptionPane;

/**
 *
 * @author manu_
 */
public class Tarea4 {

    public static void main(String[] args) {      
        int numero= Integer.parseInt(JOptionPane.showInputDialog("Introduzca un numero")); //
        if (numero<= 0) {
            System.out.println("Introduzca un número mayor que 0.");
        }
            
        else if (numero>0){
            System.out.println("El cuadrado del numero es " + Math.pow(numero,2));
            System.out.println("La raiz cuadrada del numero es " + Math.sqrt(numero));
            
                    
                    }  
        }
    
    }

