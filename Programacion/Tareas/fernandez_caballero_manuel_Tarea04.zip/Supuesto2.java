/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea4;

import java.util.Scanner;

/**
 *
 * @author manu_
 */
public class Supuesto2 {
     public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    System.out.println("Introduzca el numero de niños en el curso actual: ");
        int niños=entrada.nextInt();
    System.out.println("Introduzca el numero de niñas en el curso actual: ");
        int niñas=entrada.nextInt();
    
        int Total=niños+niñas;
        int porcentajeNiños=(100*niños)/Total;
        int porcentajeNiñas=(100*niñas)/Total;
        
        System.out.println("El porcentaje de niños en el curso actual es el:" + porcentajeNiños +"%");
        System.out.println("El porcentaje de niñas en el curso actual es el:" + porcentajeNiñas +"%");
        
        
                
        
}
}