/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tarea11;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author manu_
 */
public class MenuNotaria extends javax.swing.JFrame {

    
    public MenuNotaria() {
        ConsultaNotaria();

    }

    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String bbdd = "jdbc:mysql://localhost/test";
    private static final String usuario = "root";
    private static final String clave = "";

    Scanner teclado = new Scanner(System.in);

    public static Connection Conexion() {
        Connection conexion = null;

        try {
            Class.forName(driver);

            conexion = DriverManager.getConnection(bbdd, usuario, clave);

        } catch (Exception e) {
            System.out.println("Error al conectar con la base de datos.\n" + e.getMessage().toString());
        }

        return conexion;
    }

    public void CrearClientes() {

        Connection conn = Conexion();

        try {
            String sql = "Create table Clientes( cod_cliente int primary key, nombre varchar(30), telefono int(9));";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("La tabla se ha creado correctamente");

        } catch (SQLException ex) {
            System.out.println("La tabla ya existe");
         
        }

    }

    public void CrearEscrituras() {

        Connection conn = Conexion();

        try {
            String sql = "Create table Escrituras( cod int primary key, tipo varchar(4), nom_fich varchar(50), num_interv int);";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("La tabla se ha creado correctamente");

        } catch (SQLException ex) {
            System.out.println("La tabla ya existe");
         
        }

    }

    public void CrearEsc_Cli() {

        Connection conn = Conexion();

        try {
            String sql = "Create table EscCli( codCli int, codEsc int,"
                    + "foreign key (codCli) references clientes (cod_cliente),"
                    + "foreign key (codEsc) references escrituras (cod));";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("La tabla se ha creado correctamente");

        } catch (SQLException ex) {
            System.out.println("La tabla ya existe");
           
        }

    }

    public void InsertarCliente() {

        System.out.println("¿Quieres insertar un cliente?:\n");
        String opcion = teclado.next();

        while (opcion.equalsIgnoreCase("si")) {

            System.out.println("Introduce el código del cliente:");
            int cod = teclado.nextInt();
            System.out.println("Introduce el  nombre del cliente:");
            String nombre = teclado.next();
            System.out.println("Introduce el telefono para el cliente:");
            int tel = teclado.nextInt();

            Connection conn = Conexion();

            try {
                String sql = "insert into clientes values(" + cod + ",'" + nombre + "'," + tel + ");";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.executeUpdate();
                System.out.println("Cliente insertado correctamente.");

            } catch (SQLException ex) {
                System.out.println("Ha ocurrido un error al insertar los datos del cliente.");
               
            }

            System.out.println("¿Quieres insertar otro cliente?:");
            opcion = teclado.next();
        }
    }

    public void InsertarEscriturasConClientes() {

        System.out.println("Introduce un código:\n");
        int cod = teclado.nextInt();
        System.out.println("Introduce un tipo(TEST/CPVE)\n: ");
        String tipo = teclado.next();
        System.out.println("Introduce un fichero:\n");
        String fich = teclado.nextLine();
        fich = teclado.nextLine();
        System.out.println("Introduce intervinientes:\n");
        int inter = teclado.nextInt();

        Connection conn = Conexion();

        try {
            String sql = "insert into escrituras values(" + cod + ",'" + tipo + "','" + fich + "'," + inter + ");";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            System.out.println("Escritura insertado correctamente.");

            System.out.println("Quieres introducir un cliente para la escritura:\n?");
            String opc = teclado.next();
            if (opc.equalsIgnoreCase("si")) {
                System.out.println("Introduce el codigo del cliente:");
                int codcli = teclado.nextInt();
                sql = "insert into esccli values(" + cod + "," + codcli + ");";
                ps = conn.prepareStatement(sql);
                ps.executeUpdate();
                System.out.println("Escritura con cliente insertada correctamente.");
            }
        } catch (SQLException ex) {
            System.out.println("Ha ocurrido un error insertar un cliente");
            
        }
    }

    public void MostrarClientes() {
        Connection conn = Conexion();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from clientes;");
            JDialog salida = new JDialog();
            salida.setVisible(true);
            salida.setBounds(550, 200, 500, 450);
            salida.setTitle("Clientes");
            GridLayout sal = new GridLayout(5, 3);
            salida.setLayout(sal);
            JLabel titcod = new JLabel("Código");
            salida.add(titcod);
            JLabel titnom = new JLabel("Nombre");
            salida.add(titnom);
            JLabel tittel = new JLabel("Teléfono");
            salida.add(tittel);
            while (rs.next()) {
                JLabel codigo = new JLabel(rs.getInt("cod_cliente") + "");
                salida.add(codigo);
                JLabel nombre = new JLabel(rs.getString("nombre"));
                salida.add(nombre);
                JLabel telefono = new JLabel(rs.getInt("telefono") + "");
                salida.add(telefono);
               
            }

        } catch (SQLException ex) {
           
        }

    }
    
    public void MostrarClientesCPVE() {
        Connection conn = Conexion();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT c.* from clientes c inner join esccli sc on c.cod_cliente = sc.codCli inner join"
                    + " escrituras esc on sc.codEsc = esc.cod where esc.tipo = 'CPVE';");
            JDialog salida = new JDialog();
            salida.setVisible(true);
            salida.setBounds(550, 200, 500, 450);
            salida.setTitle("Clientes");
            GridLayout sal = new GridLayout(0, 3);
            salida.setLayout(sal);
            JLabel titcod = new JLabel("Codigo");
            salida.add(titcod);
            JLabel titnom = new JLabel("Nombre");
            salida.add(titnom);
            JLabel tittel = new JLabel("Telefono");
            salida.add(tittel);

            while (rs.next()) {

                JLabel codigo = new JLabel(rs.getInt("cod_cliente") + "");
                salida.add(codigo);

                JLabel nombre = new JLabel(rs.getString("nombre"));
                salida.add(nombre);

                JLabel telefono = new JLabel(rs.getInt("telefono") + "");
                salida.add(telefono);

               
            }

        } catch (SQLException ex) {
         
        }

    }
    
    public void MostrarEscrituras() {
        Connection conn = Conexion();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from escrituras;");
            JDialog salida = new JDialog();
            salida.setVisible(true);
            salida.setBounds(250, 200, 500, 450);
            salida.setTitle("Escrituras");
            GridLayout sal = new GridLayout(3, 4);
            salida.setLayout(sal);
            JLabel titcod = new JLabel("Codigo");
            salida.add(titcod);
            JLabel titnom = new JLabel("Tipo");
            salida.add(titnom);
            JLabel tittel = new JLabel("Fichero");
            salida.add(tittel);
            JLabel titint = new JLabel("Intervinientes");
            salida.add(titint);
            while (rs.next()) {
                JLabel codigo = new JLabel(rs.getInt("cod") + "");
                salida.add(codigo);
                JLabel tipo = new JLabel(rs.getString("tipo"));
                salida.add(tipo);
                JLabel fich = new JLabel(rs.getString("nom_fich"));
                salida.add(fich);
                JLabel interv = new JLabel(rs.getInt("num_interv") + "");
                salida.add(interv);            
            }
        } catch (SQLException ex) {
            
        }

    }

    public void ActualizarCliente() {
        Connection conn = Conexion();
        JDialog salida = new JDialog();
        salida.setVisible(true);
        salida.setBounds(250, 200, 500, 450);
        salida.setTitle("Cliente");
        GridLayout sal = new GridLayout(5, 2);
        salida.setLayout(sal);
        JLabel titcod = new JLabel("Codigo");
        salida.add(titcod);
        JTextField codt = new JTextField();
        salida.add(codt);
        JButton carga = new JButton("Cargar");
        salida.add(carga);
        JLabel titnom = new JLabel("");
        salida.add(titnom);
        JLabel tittel = new JLabel("Nombre");
        salida.add(tittel);
        JTextField nombt = new JTextField();
        salida.add(nombt);
        JLabel titint = new JLabel("Telefono");
        salida.add(titint);
        JTextField telt = new JTextField();
        salida.add(telt);
        JButton modifica = new JButton("Modificar");
        salida.add(modifica);
        carga.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Statement st = conn.createStatement();
                    ResultSet rs = st.executeQuery("select nombre,telefono from clientes where cod_cliente = " + codt.getText() + ";");
                    while (rs.next()) {
                        nombt.setText(rs.getString("nombre"));
                        telt.setText(rs.getInt("telefono") + "");
                    }
                } catch (SQLException ex) {
                  
                }
            }
        });
        modifica.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String sql = "update clientes set nombre='"+nombt.getText()+"',telefono="+telt.getText()+" where cod_cliente="+codt.getText()+";";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.executeUpdate();
                    System.out.println("Cliente actualizado correctamente");

                } catch (SQLException ex) {
                    System.out.println("Ha ocurrido un error actualizando un cliente");
                   

                }
            }
        });
    }

    public void ConsultaNotaria() {
        
        JFrame consultar = new JFrame();
        consultar.setVisible(true);
        consultar.setBounds(550, 200, 700, 350);
        consultar.setTitle("Opciones de notaria ");

        GridLayout celda = new GridLayout(3, 3);
        consultar.setLayout(celda);
        JButton boton1 = new JButton("Tabla Clientes");
        JButton boton2 = new JButton("Tabla Escrituras");
        JButton boton3 = new JButton("Tabla Esc_Cli");
        JButton boton4 = new JButton("Insertar Clientes");
        JButton boton5 = new JButton("Insertar Escrituras con clientes");
        JButton boton6 = new JButton("Listar Clientes");
        JButton boton7 = new JButton("Listar Escrituras");
        JButton boton8 = new JButton("Actualizar Cliente");
        JButton boton9 = new JButton("Listar Clientes CPVE");

        consultar.add(boton1);
        consultar.add(boton2);
        consultar.add(boton3);
        consultar.add(boton4);
        consultar.add(boton5);
        consultar.add(boton6);
        consultar.add(boton7);
        consultar.add(boton8);
        consultar.add(boton9);

        boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CrearClientes();
            }
        });

        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CrearEscrituras();
            }
        });

        boton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CrearEsc_Cli();
            }
        });

        boton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InsertarCliente();
            }
        });

        boton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InsertarEscriturasConClientes();
            }
        });

        boton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MostrarClientes();
            }
        });

        boton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MostrarEscrituras();
            }
        });
        boton8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ActualizarCliente();
            }
        });
        boton9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MostrarClientesCPVE();
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuNotaria.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuNotaria.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuNotaria.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuNotaria.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuNotaria().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
