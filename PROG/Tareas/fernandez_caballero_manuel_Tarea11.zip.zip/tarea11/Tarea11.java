/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea11;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author manu_
 */
public class Tarea11 {

    
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String bbdd = "jdbc:mysql://localhost/test";
    private static final String usuario = "root";
    private static final String clave = "";

    public static Connection Conexion() {
        Connection conexion = null;

        try {
            Class.forName(driver);

            conexion = DriverManager.getConnection(bbdd, usuario, clave);
            
            System.out.println("Conectado correctamente a la base de datos Test.");
           
        } catch (Exception e) {
            System.out.println("Error al conectar con la base de datos.\n" + e.getMessage().toString());
        }

        return conexion;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Connection conn = Conexion();
        MenuNotaria menu = new MenuNotaria();
       
    }
    
}
