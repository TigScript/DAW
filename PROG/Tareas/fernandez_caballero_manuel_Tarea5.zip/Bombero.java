/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bomberomain;

import java.time.LocalDate;
import java.util.Calendar;

/**
 *
 * @author manu_
 */
class Bombero extends Funcionario {//Se trata de una clase heredada de funcionario.
    // Sus atributos serán: puesto (de tipo Puesto) y parque (de tipo String).

  private Puesto puesto;
  private String parque;
    // Debes definir también un atributo estático que lleve la cuenta de los bomberos creados.
  private static int numBomberos = 0;

  // Constructor por defecto
  public Bombero() {
    super();
    this.puesto = new Puesto();
    this.parque = "";
    numBomberos++;
  }

    //otro con todos los parámetros (utiliza el de la clase padre con la instrucción super y añade lo que falte).
  public Bombero(String nombre, String apellidos, int edad, String fechaIngreso, Puesto puesto, String parque) {
    super(nombre, apellidos, edad, fechaIngreso);
    this.puesto = puesto;
    this.parque = parque;
    numBomberos++;
  }

  // Métodos get y set
  public Puesto getPuesto() {
    return this.puesto;
  }

  public void setPuesto(Puesto puesto) {
    this.puesto = puesto;
  }

  public String getParque() {
    return this.parque;
  }

  public void setParque(String parque) {
    this.parque = parque;
  }

  public static int getNumBomberos() {
    return numBomberos;
  }

  //Sobreescribe el método getInfo para que devuelva la información completa de Bombero
  // la palabra clave @Override para indicar que se trata de una sobreescritura del método getInfo
  //de la clase padre. Luego, se ha llamado al método getInfo de la clase padre con la instrucción super.getInfo()
  //y se ha añadido la información adicional del puesto y el parque del bombero.
  @Override
  public String getInfo() {
    return super.getInfo() + " Trabaja como " + this.puesto.getNombrePuesto() + " en el parque " + this.parque + " y su sueldo es de " + this.puesto.getSueldo() + " euros.";
  }

  // Método calculoAntiguedad
  public void calculoAntiguedad() {
      // Obtenemos la fecha actual
      LocalDate fechaActual = LocalDate.now();

      // Obtenemos la fecha de ingreso del bombero
      LocalDate fechaIngreso = LocalDate.parse(getFechaIngreso());

      // Calculamos la antigüedad del bombero en años
      long antiguedad = fechaActual.getYear() - fechaIngreso.getYear();

      // Modificamos el sueldo del puesto de acuerdo a la antigüedad
      if (antiguedad >= 10) {
         puesto.setSueldo(puesto.getSueldo() * 1.1);
      } else if (antiguedad >= 5) {
         puesto.setSueldo(puesto.getSueldo() * 1.05);
      } else if (antiguedad >= 1) {
         puesto.setSueldo(puesto.getSueldo() * 1.01);
      }
   }
  }
