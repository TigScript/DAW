/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bomberomain;

/**
 *
 * @author manu_
 */
public class Puesto {
     // nombrePuesto, categoría, descripcionPuesto, sueldo.
    private String nombrePuesto;
    private String categoria;
    private String descripcionPuesto;
    private double sueldo;

    // Constructor que rellena puesto, categoría y descripción y establece el sueldo en función de la categoría
    public Puesto(String nombrePuesto, String categoria, String descripcionPuesto) {
        this.nombrePuesto = nombrePuesto;
        this.categoria = categoria;
        this.descripcionPuesto = descripcionPuesto;
        if (categoria.equalsIgnoreCase("peon")) {
            this.sueldo = 1500;
        } else if (categoria.equalsIgnoreCase("cabo")) {
            this.sueldo = 1800;
        } else if (categoria.equalsIgnoreCase("especialista")) {
            this.sueldo = 2000;
        }
    }

    Puesto() {
        throw new UnsupportedOperationException("Not supported yet."); // 
    }

    // Métodos get y set para todos los atributos
    public String getNombrePuesto() {
        return nombrePuesto;
    }

    public void setNombrePuesto(String nombrePuesto) {
        this.nombrePuesto = nombrePuesto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDescripcionPuesto() {
        return descripcionPuesto;
    }

    public void setDescripcionPuesto(String descripcionPuesto) {
        this.descripcionPuesto = descripcionPuesto;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
}

