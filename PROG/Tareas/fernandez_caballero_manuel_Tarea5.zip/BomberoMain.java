/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.bomberomain;

import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author manu_
 */
public class BomberoMain {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //  Cree 3 objetos Puesto, uno de cada categoría, pidiendo los datos a usuario por pantalla(excepto la categoría que debe ser una de cada).
        // Puesto 1
        System.out.println("Creando tres puestos...");
        System.out.print("Introduce el nombre del puesto 1: ");
        String nombrePuesto1 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto 1: ");
        String descripcionPuesto1 = scanner.nextLine();
        Puesto puesto1 = new Puesto(nombrePuesto1, "peon", descripcionPuesto1); //instanciamos objeto de tipo Puesto
        //nombre de la clase + nombre del objeto = operador new + método constructor con los atributos modificados
        // Puesto 2
        System.out.print("Introduce el nombre del puesto 2: ");
        String nombrePuesto2 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto 2: ");
        String descripcionPuesto2 = scanner.nextLine();
        Puesto puesto2 = new Puesto(nombrePuesto2, "cabo", descripcionPuesto2); //creacion objeto tipo Puesto
        // Puesto 3
        System.out.print("Introduce el nombre del puesto 3: ");
        String nombrePuesto3 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto 3: ");
        String descripcionPuesto3 = scanner.nextLine();
        Puesto puesto3 = new Puesto(nombrePuesto3, "especialista", descripcionPuesto3); //creacion objeto tipo Puesto

        // Crea 3 objetos Bombero
        System.out.println("Creando tres bomberos...");
        System.out.print("Introduce el nombre del bombero 1: ");
        String nombreBombero1 = scanner.nextLine();
        System.out.print("Introduce los apellidos del bombero 1: ");
        String apellidosBombero1 = scanner.nextLine();
        System.out.print("Introduce la edad del bombero 1: ");
        int edadBombero1 = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Introduce la fecha de ingreso del bombero 1 (formato AAAA-MM-DD): ");
        String fechaIngresoBombero1 = scanner.nextLine();
        System.out.print("Introduce el parque del bombero 1: ");
        String parqueBombero1 = scanner.nextLine();
        System.out.print("Introduce el nombre del puesto del bombero 1: ");
        String nombrePuestoBombero1 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto del bombero 1: ");
        String descripcionPuestoBombero1 = scanner.nextLine();
        Puesto puestoBombero1 = new Puesto(nombrePuestoBombero1, "peon", descripcionPuestoBombero1);
        Bombero bombero1 = new Bombero(nombreBombero1, apellidosBombero1, edadBombero1, fechaIngresoBombero1, puestoBombero1, parqueBombero1);
        System.out.println("El bombero " + nombreBombero1 + "" + apellidosBombero1 + " con " + edadBombero1
                + " años de edad ingresó en el cuerpo el  " + fechaIngresoBombero1 + " en el puesto " + nombrePuestoBombero1 + " en el parque " + parqueBombero1);

        // Bombero 2      
        System.out.print("Introduce el nombre del bombero 2: ");
        String nombreBombero2 = scanner.nextLine();
        System.out.print("Introduce los apellidos del bombero 2: ");
        String apellidosBombero2 = scanner.nextLine();
        System.out.print("Introduce la edad del bombero 2: ");
        int edadBombero2 = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Introduce la fecha de ingreso del bombero 2 (formato AAAA-MM-DD): ");
        String fechaIngresoBombero2 = scanner.nextLine();
        System.out.print("Introduce el parque del bombero 2: ");
        String parqueBombero2 = scanner.nextLine();
        System.out.print("Introduce el nombre del puesto del bombero 2: ");
        String nombrePuestoBombero2 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto del bombero 2: ");
        String descripcionPuestoBombero2 = scanner.nextLine();
        Puesto puestoBombero2 = new Puesto(nombrePuestoBombero2, "peon", descripcionPuestoBombero2);
        Bombero bombero2 = new Bombero(nombreBombero2, apellidosBombero2, edadBombero2, fechaIngresoBombero2, puestoBombero2, parqueBombero2);
        System.out.println("El bombero " + nombreBombero2 + "" + apellidosBombero2 + " con " + edadBombero2
                + " años de edad ingresó en el cuerpo el  " + fechaIngresoBombero2 + " en el puesto " + nombrePuestoBombero2 + " en el parque " + parqueBombero2);

        // Bombero 3      
        System.out.print("Introduce el nombre del bombero 3: ");
        String nombreBombero3 = scanner.nextLine();
        System.out.print("Introduce los apellidos del bombero 3: ");
        String apellidosBombero3 = scanner.nextLine();
        System.out.print("Introduce la edad del bombero 3: ");
        int edadBombero3 = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Introduce la fecha de ingreso del bombero 3 (formato AAAA-MM-DD): ");
        String fechaIngresoBombero3 = scanner.nextLine();
        System.out.print("Introduce el parque del bombero 3: ");
        String parqueBombero3 = scanner.nextLine();
        System.out.print("Introduce el nombre del puesto del bombero 3: ");
        String nombrePuestoBombero3 = scanner.nextLine();
        System.out.print("Introduce la descripción del puesto del bombero 3: ");
        String descripcionPuestoBombero3 = scanner.nextLine();
        Puesto puestoBombero3 = new Puesto(nombrePuestoBombero3, "peon", descripcionPuestoBombero3);
        Bombero bombero3 = new Bombero(nombreBombero3, apellidosBombero3, edadBombero3, fechaIngresoBombero3, puestoBombero3, parqueBombero3);
        System.out.println("El bombero " + nombreBombero3 + "" + apellidosBombero3 + " con " + edadBombero3
                + " años de edad ingresó en el cuerpo el  " + fechaIngresoBombero3 + " en el puesto " + nombrePuestoBombero3 + " en el parque " + parqueBombero3);

        // Muestra el número de bomberos creados
        System.out.println("Número de bomberos creados: " + Bombero.getNumBomberos());

        //Establezca la fecha de ingreso del bombero 1 a más de un año,
        //Creamos un objeto Date con la fecha de hoy       
        Date hoy = new Date();
        // obtiene la fecha y hora actual menos 1 año
        Date nuevoIngreso = new Date(hoy.getYear() - 1, hoy.getMonth(), hoy.getDate());  
        // convierte a String
        String fecha = nuevoIngreso.toString(); 
        bombero1.setFechaIngreso(fecha);
        //la del bombero 2 a más de 5 años
        nuevoIngreso = new Date(hoy.getYear() - 5, hoy.getMonth(), hoy.getDate());
        
        bombero2.setFechaIngreso(fecha);
        //y la del bombero 3 a más de 10 años,
        nuevoIngreso = new Date(hoy.getYear() - 10, hoy.getMonth(), hoy.getDate());
        bombero2.setFechaIngreso(fecha);

        // calcule su antigüedad y muestre el sueldo nuevo por pantalla.
        // bombero1
        bombero1.calculoAntiguedad();
        bombero1.getInfo();
        // bombero2
        bombero2.calculoAntiguedad();
        bombero2.getInfo();
        //bombero 3
        bombero3.calculoAntiguedad();
        bombero3.getInfo();
        //Solicite al usuario el puesto del bombero1 y lo asigne al objeto, recalcule su antigüedad y muestre su sueldo por pantalla.
        System.out.print("Introduce el nombre del puesto para el bombero 1: ");
        String cambiaPuestoBombero1 = scanner.nextLine();
               
      
        //Creamos un nuevo objeto "Puesto" vacío
        Puesto nuevoPuesto = new Puesto();
        //Usamos los setter de Puesto para añadirle la información
        nuevoPuesto.setNombrePuesto(cambiaPuestoBombero1);     
        nuevoPuesto.setCategoria("peon");
        
        //Asignamos el nuevo objeto Puesto al primer Bombero
        bombero1.setPuesto(nuevoPuesto);
        //Recalculamos la antiguedad
        bombero1.calculoAntiguedad();
        //Y mostramos la información del bombero por pantalla
        bombero1.getInfo();
             
        //Asigna al bombero 1 el Puesto del bombero 2 y al bombero 3 el Parque del bombero 1.
        bombero1.setPuesto(bombero2.getPuesto());
        bombero3.setParque(bombero1.getParque());
        //Con esto, el bombero 1 quedará con el puesto del bombero 2 y el bombero 3 quedará con el parque del bombero 1.

    }

}
