/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bomberomain;

/**
 *
 * @author manu_
 */
public class Funcionario {
     //Sus atributos serán: nombre, apellidos, edad, fechaIngreso.
  private String nombre;
  private String apellidos;
  private int edad;
  private String fechaIngreso; // En el método cálculo antigüedad en la línea 
    //Date fechaIngreso = formatter.parse(supergetFechaIngreso());  me da el siguiente error: Incompatible types: LocalDate cannot be converted to string.
    //Así que he decidido cambiar el tipo de fechaIngreso de LocalDate a string para solucionarlo

  // Constructor por defecto
  public Funcionario() {
    this.nombre = "";
    this.apellidos = "";
    this.edad = 0;
    this.fechaIngreso = "";
      //No tengo claro si en el constructor por defecto debo inicializar los valores por defecto o dejarlo vacío
  }

  // Constructor con todos los parámetros
  public Funcionario(String nombre, String apellidos, int edad, String fechaIngreso) {
    this.nombre = nombre;
    this.apellidos = apellidos;
    this.edad = edad;
    this.fechaIngreso = fechaIngreso;
  }

  // Métodos get y set
  public String getNombre() {
    return this.nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getApellidos() {
    return this.apellidos;
  }

  public void setApellidos(String apellidos) {
    this.apellidos = apellidos;
  }

  public int getEdad() {
    return this.edad;
  }

  public void setEdad(int edad) {
    this.edad = edad;
  }

  public String getFechaIngreso() {
    return this.fechaIngreso;
  }

  public void setFechaIngreso(String fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

// Crea un método getInfo que devuelva toda la información en un String,
    //de tipo: “El funcionario nombre  apellidos, tiene edad años e ingresó en el cuerpo fechaIngreso.”
  public String getInfo() {
    return "El funcionario " + this.nombre + " " + this.apellidos + ", tiene " + this.edad + " años e ingresó en el cuerpo " + this.fechaIngreso + ".";
  }
}

