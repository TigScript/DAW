
package tarea9;

import java.util.ArrayList;

/**
 *
 * @author manu_
 */
public class Tarea9 {

    public static int numUsuarios=0;
 
    public static void main(String[] args) {
         // Creo dos objetos de Fitness
        
        Fitness fitness1 = new Fitness(Fitness.INTENSIDAD.alta,10,"Crossfit",2020);
        Fitness fitness2 = new Fitness(Fitness.INTENSIDAD.media,20,"Spinning",2022);
        
        // Creo un objeto de Wellness
        Wellness wellness1 = new Wellness("Guantes",Wellness.DIFICULTAD.principiante,"Boxeo",2021);
        
         // Creo un usuario y lo apuntoa los tres deportes
        
        Usuario usuario1 = new Usuario(1,"Manuel","Fernández","1994-01-01");
        
        // se debe llevar la cuenta de los usuarios creados
        
        numUsuarios++;
        
        usuario1.altaDeporte(fitness1);
        usuario1.altaDeporte(fitness2);
       usuario1.altaDeporte(wellness1);
       
       //mostrar deporte del usuario
        
        usuario1.MostrarDeportes();
        
        //dar de baja el deporte fitness 2, Spinning
        
        usuario1.bajaDeporte(fitness2);
        //mostrar deportes después de la baja
        
         usuario1.MostrarDeportes();
    }
    
}
