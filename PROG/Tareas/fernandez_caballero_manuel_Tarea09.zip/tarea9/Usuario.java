
package tarea9;

import java.util.ArrayList;

/**
 *
 * @author manu_
 */
public class Usuario implements Gimnasio{
    public int id;
    public String nombre;
    public String apellidos;
    public String fecha_nac;
    ArrayList<Deporte> deportes = new ArrayList<Deporte>();
    
    
    public Usuario(){
        
    }

    public Usuario(int id, String nombre, String apellidos, String fecha_nac) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fecha_nac = fecha_nac;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(String fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public ArrayList<Deporte> getDeportes() {
        return deportes;
    }

    public void setDeportes(ArrayList<Deporte> deportes) {
        this.deportes = deportes;
    }

    @Override
    public void altaDeporte(Deporte d) {
        this.deportes.add(d);
        
    }

    @Override
    public void MostrarDeportes() {
        for(int i = 0; i<this.deportes.size();i++){
            System.out.println(this.deportes.get(i).getInfo());
        }
        
    }

    @Override
    public void bajaDeporte(Deporte d) {
        for(int i = 0; i<this.deportes.size();i++){
            if(d.getNombre().equals(this.deportes.get(i).getNombre()))
                this.deportes.remove(i);
        }
    }
    
}
