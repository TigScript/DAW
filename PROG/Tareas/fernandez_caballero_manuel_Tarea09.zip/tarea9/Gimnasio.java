
package tarea9;

/**
 *
 * @author manu_
 */
public interface Gimnasio {
    public void altaDeporte(Deporte d);
    public void MostrarDeportes();
    public void bajaDeporte(Deporte d);
    
    
}
