
package tarea9;

/**
 *
 * @author manu_
 */
public abstract class Deporte {
    
    public  String nombre;
    public  int creacion;
    
    
    public Deporte(){
        
    }

    public Deporte(String nombre, int creacion) {
        this.nombre = nombre;
        this.creacion = creacion;
    }

    public String getNombre() {
        return nombre;
    }

    private void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCreacion() {
        return creacion;
    }

    private void setCreacion(int creacion) {
        this.creacion = creacion;
    }

    
    public String getInfo() {
        return "Deporte{" + "nombre=" + nombre + ", creacion=" + creacion + '}';
    }
    
    
}
