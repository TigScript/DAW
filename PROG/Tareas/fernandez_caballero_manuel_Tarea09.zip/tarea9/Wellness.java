
package tarea9;

/**
 *
 * @author manu_
 */
public class Wellness extends Deporte{
    public enum DIFICULTAD{principiante,avanzado};
    
    public String material;
    
    public DIFICULTAD dificultad;
    
    public Wellness(){
        
    }

    public Wellness(String material, DIFICULTAD dificultad, String nombre, int creacion) {
        super(nombre, creacion);
        this.material = material;
        this.dificultad = dificultad;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public DIFICULTAD getDificultad() {
        return dificultad;
    }

    public void setDificultad(DIFICULTAD dificultad) {
        this.dificultad = dificultad;
    }

    @Override
    public String getInfo() {
        return super.getInfo()+" Wellness{" + "material=" + material + ", dificultad=" + dificultad + '}';
    }
    
    
}
