
package tarea9;

/**
 *
 * @author manu_
 */
public class Fitness extends Deporte{
    public enum INTENSIDAD{baja,media,alta};
    
    public INTENSIDAD intensidad;
    
    public int max_alumnos;
    
    public Fitness(){
        
    }

    public Fitness(INTENSIDAD intensidad, int max_alumnos, String nombre, int creacion) {
        super(nombre, creacion);
        this.intensidad = intensidad;
        this.max_alumnos = max_alumnos;
    }

    public INTENSIDAD getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(INTENSIDAD intensidad) {
        this.intensidad = intensidad;
    }

    public int getMax_alumnos() {
        return max_alumnos;
    }

    public void setMax_alumnos(int max_alumnos) {
        this.max_alumnos = max_alumnos;
    }

    @Override
    public String getInfo() {
        return super.getInfo()+" Fitness{" + "intensidad=" + intensidad + ", max_alumnos=" + max_alumnos + '}';
    }
    
    
}
