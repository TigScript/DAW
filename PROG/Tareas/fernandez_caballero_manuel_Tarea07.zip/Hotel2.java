/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.hotel2;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

/**
 *
 * @author manu_
 */
public class Hotel2 extends JFrame  {
     public ArrayList<Habitacion> habitaciones = new ArrayList<Habitacion>();
    int dia=0;
    int mes=0;
    int anio=0;
     
    public void RellenaHabitaciones() {
        for (int i = 1; i <= 5; i++) {
            Habitacion hab = new Habitacion(i, true, 100);
            habitaciones.add(hab);
        }

        for (int i = 6; i <= 10; i++) {
            Habitacion hab = new Habitacion(i, true, 150);
            habitaciones.add(hab);
        }

    }
    public Hotel2(){
        
        RellenaHabitaciones();
         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(300, 100, 300, 300);
        setTitle("Hotel");
        
        
         JMenuBar barraMenu = new JMenuBar();

        //Creamos los menus
        JMenu archivo = new JMenu("Menu");

        //AÃ±adimos los menus a la barra de menu
        barraMenu.add(archivo);

        JMenuItem consulta = new JMenuItem("Consultar habitaciones");
        JMenuItem salida = new JMenuItem("Salida de los huespedes");

        //AÃ±adimos los submenus a los menus
        archivo.add(consulta);
        archivo.add(new JSeparator());
        archivo.add(salida);

        //Indicamos que es el menu por defecto
        setJMenuBar(barraMenu);
        
        consulta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ConsultaHabitaciones();

            }
        });
        
        salida.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Salida();
            }
        });

    }
    
    public void Salida() {
        JDialog salida = new JDialog();
        salida.setVisible(true);
        salida.setBounds(100, 100, 450, 300);
        salida.setTitle("Salida de Huespedes");
        GridLayout sal = new GridLayout(3, 1);
        salida.setLayout(sal);

        JLabel ingrese = new JLabel("Ingrese numero de la Habitacion");
        JTextField tingrese = new JTextField();
        salida.add(ingrese);
        salida.add(tingrese);
        JButton aceptar = new JButton("OK");
        salida.add(aceptar);
        JButton cancelar = new JButton("Cancelar");
        salida.add(cancelar);

        aceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salida.dispose();
                SalidaHuesped(Integer.parseInt(tingrese.getText()));
            }
        });

        cancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salida.dispose();

            }
        });

    }

    
    public void SalidaHuesped(int numero) {
        JFrame ingreso = new JFrame();
        ingreso.setVisible(true);
        ingreso.setBounds(100, 100, 450, 300);
        ingreso.setTitle("Salida Huesped");

        GridLayout celda = new GridLayout(8, 1);
        ingreso.setLayout(celda);

        JLabel habitacion = new JLabel("Habitacion:" + numero);
        ingreso.add(habitacion);

        JLabel numhabitacion = new JLabel();

        for (int i = 0; i < habitaciones.size(); i++) {
            if (habitaciones.get(i).getNumero() == numero) {
                numhabitacion = new JLabel("Fechan de ingreso:" + habitaciones.get(i).getFecha());
                ingreso.add(numhabitacion);
                //String fecha2 = numhabitacion.getText().substring(numhabitacion.getText().length() - 2, numhabitacion.getText().length());
                //int fent = Integer.parseInt(fecha2);
                
                String[] fechas = habitaciones.get(i).getFecha().split("-");
                anio=Integer.parseInt(fechas[0]);
                mes=Integer.parseInt(fechas[1]);
                dia =Integer.parseInt(fechas[2]);
            }
        }
        JLabel fecha = new JLabel("Fecha de salida(aaaa-mm-dd):");
        ingreso.add(fecha);
        JTextField tfecha = new JTextField();
        ingreso.add(tfecha);
        JButton calcular = new JButton("Calcular");
        ingreso.add(calcular);
        JLabel huesped = new JLabel("Cantidad de dias:");
        ingreso.add(huesped);
        JLabel vacio = new JLabel("Total: ");
        ingreso.add(vacio);

        JButton registro = new JButton("REgitrar Salida");
        registro.setEnabled(false);
        ingreso.add(registro);

        calcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                //String fecha1 = tfecha.getText().substring(tfecha.getText().length() - 2, tfecha.getText().length());
                
                String[] fechassal = tfecha.getText().split("-");
                int aniosal = Integer.parseInt(fechassal[0]);
                int messal = Integer.parseInt(fechassal[1]);
                int diasal = Integer.parseInt(fechassal[2]);
                
                if(diasal < dia){
                    if(messal<=mes){
                        if(aniosal<=anio)
                            CamposIncorrectos();
                        else
                            diasal = diasal + ((aniosal-anio)*365);
                    }else{
                        diasal = diasal + ((messal-mes)*30);
                        if(aniosal>anio)
                            diasal = diasal + ((aniosal-anio)*365);
                    }
                }

                huesped.setText("Cantidad de dias:" + (diasal - dia));

                for (int i = 0; i < habitaciones.size(); i++) {
                    if (habitaciones.get(i).getNumero() == numero) {
                        int precio = habitaciones.get(i).getPrecio();
                        vacio.setText("Total:" + (diasal - dia) * precio);
                    }
                }
                registro.setEnabled(true);
            }
        });

        registro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                for (int i = 0; i < habitaciones.size(); i++) {
                    if (habitaciones.get(i).getNumero() == numero) {
                        habitaciones.get(i).setDisponible(true);
                        ingreso.dispose();
                    }
                }
            }
        });

    }

    
    public void ConsultaHabitaciones() {
        JFrame consultar = new JFrame();
        consultar.setVisible(true);
        consultar.setBounds(100, 100, 450, 300);
        consultar.setTitle("Habitaciones");

        GridLayout celda = new GridLayout(3, 5);
        consultar.setLayout(celda);

        for (int i = 0; i < habitaciones.size(); i++) {
            JPanel panel1 = new JPanel();
            GridLayout celda1 = new GridLayout(2, 1);
            panel1.setLayout(celda1);
            JLabel habitacion1 = new JLabel("Habitacion" + habitaciones.get(i).getNumero());
            panel1.add(habitacion1);
            if (habitaciones.get(i).Disponible) {
                JLabel disponible1 = new JLabel("Disponible");
                panel1.add(disponible1);
            } else {
                JLabel disponible1 = new JLabel("No Disponible");
                panel1.add(disponible1);
            }

            consultar.add(panel1);
        }

        JLabel reservar = new JLabel("Habitacion a reservar:");
        consultar.add(reservar);
        SpinnerModel sm = new SpinnerNumberModel(1, 1, 10, 1);
        JSpinner spinner = new JSpinner(sm);
        consultar.add(spinner);
        JButton aceptar = new JButton("Aceptar");
        consultar.add(aceptar);

        aceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < habitaciones.size(); i++) {
                    if (habitaciones.get(i).getNumero() == (int) spinner.getValue()) {
                        if (habitaciones.get(i).Disponible) {
                            consultar.dispose();
                            Ingreso(habitaciones.get(i).getNumero());
                        } else {
                            consultar.dispose();
                            NoDisponible();
                        }
                    }
                }
                //To change body of generated methods, choose Tools | Templates.
            }
        });

    }
    
     public void Ingreso(int numero) {
        JFrame ingreso = new JFrame();
        ingreso.setVisible(true);
        ingreso.setBounds(100, 100, 450, 300);
        ingreso.setTitle("Ingreso");

        GridLayout celda = new GridLayout(7, 2);
        ingreso.setLayout(celda);

        JLabel habitacion = new JLabel("Habitacion:");
        ingreso.add(habitacion);
        JLabel numhabitacion = new JLabel("" + numero);
        ingreso.add(numhabitacion);
        JLabel fecha = new JLabel("Fecha (aaaa-mm-dd):");
        ingreso.add(fecha);
        JTextField tfecha = new JTextField();
        ingreso.add(tfecha);
        JLabel huesped = new JLabel("Huesped");
        ingreso.add(huesped);
        JLabel vacio = new JLabel("");
        ingreso.add(vacio);
        JLabel nombre = new JLabel("Nombre:");
        ingreso.add(nombre);
        JTextField tnombre = new JTextField();
        ingreso.add(tnombre);
        JLabel apellidos = new JLabel("Apellidos:");
        ingreso.add(apellidos);
        JTextField tapellidos = new JTextField();
        ingreso.add(tapellidos);
        JLabel nif = new JLabel("Doc. Identidad:");
        ingreso.add(nif);
        JTextField tnif = new JTextField();
        ingreso.add(tnif);
        JButton aceptar = new JButton("Aceptar");

        ingreso.add(aceptar);
        JButton cancelar = new JButton("Cancelar");
        ingreso.add(cancelar);

        aceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (tfecha.getText().equals("") || tnombre.getText().equals("") || tapellidos.getText().equals("") || tnif.getText().equals("")) {
                    CamposIncorrectos();

                } else {
                    for (int i = 0; i < habitaciones.size(); i++) {
                        if (habitaciones.get(i).getNumero() == numero) {
                            String fecha1 = tfecha.getText();

                            habitaciones.get(i).setFecha(fecha1);

                            habitaciones.get(i).setDisponible(false);

                        }
                    }
                    ingreso.dispose();
                    Registrado();
                }
            }
        });

        cancelar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                ingreso.dispose();

            }
        });

    }
    
     
     public void CamposIncorrectos() {
        JDialog salida = new JDialog();
        salida.setVisible(true);
        salida.setBounds(100, 100, 450, 300);
        salida.setTitle("Error");
        GridLayout sal = new GridLayout(2, 1);
        salida.setLayout(sal);

        JLabel ingrese = new JLabel("Revise los campos a rellenar");

        salida.add(ingrese);
        JButton aceptar = new JButton("OK");
        salida.add(aceptar);

        aceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                salida.dispose();
                
            }
        });

    }
    public void Registrado() {
        JDialog salida = new JDialog();
        salida.setVisible(true);
        salida.setBounds(100, 100, 450, 300);
        salida.setTitle("Registrado");
        GridLayout sal = new GridLayout(2, 1);
        salida.setLayout(sal);

        JLabel ingrese = new JLabel("El Huesped ha sido registrado");

        salida.add(ingrese);
        JButton aceptar = new JButton("OK");
        salida.add(aceptar);

        aceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                salida.dispose();
                ConsultaHabitaciones();
            }
        });

    }
    
     public void NoDisponible() {
        JDialog salida = new JDialog();
        salida.setVisible(true);
        salida.setBounds(100, 100, 450, 300);
        salida.setTitle("NoDisponible");
        GridLayout sal = new GridLayout(2, 1);
        salida.setLayout(sal);

        JLabel ingrese = new JLabel("Habitacion No Disponible");

        salida.add(ingrese);
        JButton aceptar = new JButton("OK");
        salida.add(aceptar);

        aceptar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                salida.dispose();
                ConsultaHabitaciones();
            }
        });
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Hotel2 frame = new Hotel2();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        
    }
    
}