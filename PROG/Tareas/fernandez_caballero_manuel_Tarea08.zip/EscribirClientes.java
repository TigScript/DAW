
package com.mycompany.tarea8;

import java.io.File;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

/**
 *
 * @author manu_
 */
public class EscribirClientes {

    public EscribirClientes() throws TransformerException {
        try {
            //instancia de DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // documentBuilder
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Creo un DOMImplementation
            DOMImplementation implementation = builder.getDOMImplementation();

            // Creo un documento con un elemento raiz llamado empresa
            Document documento = implementation.createDocument(null, "empresa", null);
            documento.setXmlVersion("1.0");

            // Creo los elementos
            Element clientes = documento.createElement("clientes");

            AnadirClientes(documento,clientes);

            // Añado al root el elemento clientes
            documento.getDocumentElement().appendChild(clientes);

            // Asocio el source con el Document
            Source source = new DOMSource(documento);
            // Creo el Result, indicado que fichero se va a crear
            Result result = new StreamResult(new File("empresa.xml"));

            // Creo un transformer, se crea el fichero XML
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.transform(source, result);

        } catch (ParserConfigurationException | TransformerException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void AnadirClientes(Document documento, Element clientes) {
        Scanner teclado = new Scanner(System.in);
        String respuesta ="";
        do{
        
        Element cliente = documento.createElement("cliente");

        // DNI
        Element nif = documento.createElement("nif");
        System.out.println("Introduce el dni: ");
        String dni = teclado.next();
        Text textNif = documento.createTextNode(dni);
        nif.appendChild(textNif);
        cliente.appendChild(nif);

        // Nombre
        Element nombre = documento.createElement("nombre");
        System.out.println("Introduce el nombre: ");
        String tnombre = teclado.next();
        Text textNombre = documento.createTextNode(tnombre);
        nombre.appendChild(textNombre);
        cliente.appendChild(nombre);

        // Telefono
        Element telefono = documento.createElement("telefono");
        System.out.println("Introduce el telefono: ");
        String ttelefono = teclado.next();
        Text textTelefono = documento.createTextNode(ttelefono);
        telefono.appendChild(textTelefono);
        cliente.appendChild(telefono);

        // Direccion
        Element dir = documento.createElement("dir");
        System.out.println("Introduce la direccion: ");
        String tdir = teclado.next();
        Text textDir = documento.createTextNode(tdir);
        dir.appendChild(textDir);
        cliente.appendChild(dir);

        // Deuda
        Element deuda = documento.createElement("deuda");
        System.out.println("Introduce la deuda: ");
        String tdeuda = teclado.next();
        Text textDeuda = documento.createTextNode(tdeuda);
        deuda.appendChild(textDeuda);
        cliente.appendChild(deuda);

        // Añado al elementos
        clientes.appendChild(cliente);       
        System.out.println("Cliente añadido.¿Quieres introducir mas clientes?");
         respuesta = teclado.next();
        
        }while(!respuesta.equals("N")&& !respuesta.equals("n")
                &&!respuesta.equals("No")&&!respuesta.equals("no"));

    }

}
