
package com.mycompany.tarea8;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

/**
 *
 * @author manu_
 */
public class LeerClientes {

    ArrayList<Cliente> clientes = new ArrayList<Cliente>();

    public LeerClientes() throws IOException, SAXException {
        try {
            // Creo una instancia de DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Creo un documentBuilder
            DocumentBuilder builder = factory.newDocumentBuilder();

            // Obtengo el documento, a partir del XML
            Document documento = builder.parse(new File("empresa.xml"));

            // Cojo todas las etiquetas "cliente" del cocumento
            NodeList listaClientes = documento.getElementsByTagName("cliente");

            // Recorro las etiquetas con bucle for
            for (int i = 0; i < listaClientes.getLength(); i++) {
                String dni = "";
                String nombre = "";
                String telefono = "";
                String direccion = "";
                String deuda = "";
                // Cojo el nodo actual
                Node nodo = listaClientes.item(i);
                // Compruebo si el nodo es un elemento
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    // Lo transformo a Element
                    Element e = (Element) nodo;
                    // Obtengo sus hijos
                    NodeList hijos = e.getChildNodes();
                    // Recorro sus hijos
                    for (int j = 0; j < hijos.getLength(); j++) {

                        // Obtengo al hijo actual
                        Node hijo = hijos.item(j);
                        // Compruebo si es un nodo
                        if (hijo.getNodeType() == Node.ELEMENT_NODE) {
                            // Muestro el contenido
                            System.out.println("Elemento: " + hijo.getNodeName()
                                    + ", Valor: " + hijo.getTextContent());
                            if (hijo.getNodeName().equals("nif")) {
                                dni = hijo.getTextContent();
                            } else if (hijo.getNodeName().equals("nombre")) {
                                nombre = hijo.getTextContent();
                            } else if (hijo.getNodeName().equals("telefono")) {
                                telefono = hijo.getTextContent();
                            } else if (hijo.getNodeName().equals("dir")) {
                                direccion = hijo.getTextContent();
                            } else if (hijo.getNodeName().equals("deuda")) {
                                deuda = hijo.getTextContent();
                            }
                        }

                    }
                    System.out.println("");
                }
                Cliente cliente = new Cliente(dni, nombre, telefono, direccion, deuda);
                clientes.add(cliente);
            }

        } catch (ParserConfigurationException | SAXException | IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void MostrarMayorDeuda() {
        
        int mayor = Integer.parseInt(clientes.get(0).getDeuda());
        int aux = 0;
        for (int i = 1; i < clientes.size(); i++) {
           
            if(mayor < Integer.parseInt(clientes.get(i).getDeuda()))
            {
                mayor = Integer.parseInt(clientes.get(i).getDeuda());
                aux = i;
                
            }
        }

        System.out.println(clientes.get(aux).toString());
    }

}
