/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.tarea8;

import java.io.IOException;
import java.util.Scanner;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;

/**
 *
 * @author manu_
 */
public class Tarea8 {

       
    public static void main(String[] args) throws TransformerException, IOException, SAXException {
   // EscribirClientes nuevo = new EscribirClientes();
      
     LeerClientes leer = new LeerClientes();
      
      leer.MostrarMayorDeuda();
    }

}
