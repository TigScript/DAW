/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea6;

/**
 *
 * @author manu_ Enunciado. Se trata de hacer una aplicación en Java que
 * gestione los clientes de una empresa. Esos datos, se almacenarán en un
 * fichero serializado, denominado clientes.dat. Los datos que se almacenarán
 * sobre cada cliente son: NIF. Nombre. Teléfono. Dirección. Deuda. Mediante un
 * menú se podrán realizar determinadas operaciones: Añadir cliente. Esta opción
 * pedirá los datos del cliente y añadirá el registro correspondiente en el
 * fichero. Listar clientes. Recorrerá el fichero mostrando los clientes
 * almacenados en el mismo. Buscar clientes. Pedirá al usuario el nif del
 * cliente a buscar, y comprobará si existe en el fichero. Borrar cliente.
 * Pedirá al usuario el nif del cliente a borrar, y si existe, lo borrará del
 * fichero. Borrar fichero de clientes completamente. Elimina del disco el
 * fichero clientes.dat Salir de la aplicación.
 */
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Tarea6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sn = new Scanner(System.in);
        sn.useDelimiter("\n"); //Cada vez que el método next() o nextLine() se llama en el objeto Scanner, devolverá el siguiente fragmento de texto hasta el próximo carácter de nueva línea.

        boolean salir = false;
        boolean encontrado = false;
        int opcion;

        File fichero = new File("clientes.dat"); //nueva instancia de la clase File,
        //con el nombre "clientes.dat". La clase File en Java representa un archivo o un directorio en el sistema de archivos.
        //En este caso, el archivo se llama "clientes.dat" y se almacena en el directorio actual.
        //El archivo puede ser utilizado para acceder y manipular información en el sistema de archivos, como leer y escribir datos.

        String DNI, nombre, telefono, direccion, deuda;
        //declaro telefono como string y no como int porque un int podría no caber y si se incluye el +34 sería alfanumérico

        Cliente c;

        while (!salir) {

            System.out.println("1. Crear Fichero");
            System.out.println("2. A\u00F1adir cliente"); // no sé por qué no va la ñ
            System.out.println("3. Listar clientes");
            System.out.println("4. Buscar clientes introduciendo DNI");
            System.out.println("5. Borrar cliente introduciendo DNI");
            System.out.println("6. Borrar fichero");
            System.out.println("7. Salir de la aplicacion");

            try {

                System.out.println("Escribe una opcion:");
                opcion = sn.nextInt();

                switch (opcion) {
                    //Barajamos las opciones de si el fichero clientes.dat está previamente creado o no
                    case 1:

                        //Si el fichero existe, lo indico
                        if (fichero.exists()) {
                            System.out.println("El fichero ya esta creado");
                        } else {
                            //si no existe lo creo, si hay algun problema avisa al usuario
                            if (fichero.createNewFile()) {
                                System.out.println("Se ha creado el fichero correctamente");
                            } else {
                                System.out.println("Ha habido un error al crear el fichero");
                            }
                        }

                        break;
                    case 2:

                        //Si existe el fichero, pide datos
                        if (fichero.exists()) {
                            System.out.println("Introduce un DNI:");
                            DNI = sn.next();

                            //Si el DNI no es valido, saltara la excepcion y volvera al inicio
                            validarDNI(DNI); //El código de la función validarDNI no es mío

                            System.out.println("Introduce el nombre:");
                            nombre = sn.next();

                            System.out.println("Introduce un telefono:");
                            telefono = sn.next();

                            System.out.println("Introduce la direccion:");
                            direccion = sn.next();

                            System.out.println("Introduce la deuda:");
                            deuda = sn.next();

                            c = new Cliente(DNI, nombre, telefono, direccion, deuda);

                            ObjectOutputStream oos;

                            //Si el fichero esta vacio, escribiremos con Objectoutputstream
                            if (fichero.length() == 0) {
                                oos = new ObjectOutputStream(new FileOutputStream(fichero));
                            } else {
                                //y si no esta vacio, que lo haga de esta manera, ya que cada vez que se crea un objeto crea una cabecera, pero que no lo haga si este ya esta creado
                                oos = new MiObjectOutputStream(new FileOutputStream(fichero, true)); //true para no sobreescribir lo que ya haya escrito
                            }

                            //lo inserta en el fichero
                            oos.writeObject(c);

                            System.out.println("Se ha añadido correctamente");

                        } else {
                            System.out.println("Debes crear el fichero");
                        }

                        break;
                    case 3:

                        //si existe el fichero lo lee
                        if (fichero.exists()) {

                            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fichero));

                            //Saldrá cuando no haya mas datos que leer, EOFException
                            //para leer ficheros usamos un while (true) ->
                            while (true) {

                                //leo el objeto
                                c = (Cliente) ois.readObject(); //casting

                                //lo muestro
                                System.out.println(c.toString());

                            }
                        } else {
                            System.out.println("Debes crear el fichero");
                        }

                    case 4://Buscar clientes
                        Scanner sc = new Scanner(System.in);
                        System.out.print("Introduce DNI a buscar: ");
                        String dni = sc.nextLine();
                        validarDNI(dni); //validamos el dni
                        try {
                            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("clientes.dat"));
                            c = (Cliente) ois.readObject();
                            while (c != null) {
                                if (c.getDNI().equals(dni)) {
                                    System.out.println("Cliente encontrado: ");
                                    System.out.println("DNI: " + c.getDNI());
                                    System.out.println("Nombre: " + c.getNombre());
                                    System.out.println("Teléfono: " + c.getTelefono());
                                    System.out.println("Dirección: " + c.getDireccion());
                                    System.out.println("Deuda: " + c.getDeuda());
                                    encontrado = true;
                                    break;
                                }
                                c = (Cliente) ois.readObject();
                            }
                            ois.close();
                        } catch (EOFException e) {
                            if (!encontrado) {
                                System.out.println("Cliente no encontrado");
                            }
                        } catch (IOException | ClassNotFoundException e) {
                        }

                        break;

                    case 5://Borrar cliente
                        Scanner sc2 = new Scanner(System.in);
                        System.out.print("Introduce DNI del cliente a borrar: ");
                        String dni2 = sc2.nextLine();

                        borrarCliente(dni2);

                        break;
                    case 6:

                        if (fichero.exists()) { // si existe el fichero, lo borramos
                            fichero.delete();  //borrar
                            System.out.println("El fichero se ha borrado");
                        } else { //si no existe el fichero
                            System.out.println("No se puede borrar ya que no existe el fichero");
                        }

                        break;
                    case 7:
                        salir = true;
                        break;
                }

            } catch (InputMismatchException e) {
                System.out.println(e.getMessage());
                sn.next();
            } catch (EOFException ex) { //Excepcion para ObjectInputStream
                System.out.println("No hay mas clientes");
            } catch (DNIException | IOException | ClassNotFoundException ex) {
                System.out.println(ex.getMessage());
            }

        }
    }

    //funcion borrarCliente
    public static void borrarCliente(String dni) {
        try ( ObjectInputStream ois = new ObjectInputStream(new FileInputStream("clientes.dat"))) {
            List<Cliente> clientes = new ArrayList<>();
            Cliente cliente;
            boolean existe = false;
            // Leer cada cliente del fichero
            while ((cliente = (Cliente) ois.readObject()) != null) {
                // Si el DNI no es el especificado, agregar el cliente a la lista
                if (!cliente.getDNI().equals(dni)) {
                    clientes.add(cliente);
                } else {
                    existe = true;
                }
            }
            if (existe) {
                // Sobreescribir el fichero con los clientes de la lista
                try ( ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("clientes.dat"))) {
                    for (Cliente c : clientes) {
                        oos.writeObject(c);
                    }
                    System.out.println("El cliente con DNI " + dni + " ha sido borrado.");
                }
            } else {
                System.out.println("No se ha encontrado ningun cliente con DNI " + dni);
            }
        } catch (EOFException e) {
            // Fin del fichero
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error al leer del fichero clientes.dat: " + e);
        }
    }

    /**
     * Código que valida DNI(No es mío) Valida un DNI Comprueba si tiene entre 8
     * y 9 caracteres Comprueba si la parte numerica es correcta Comprueba si la
     * letra es correcta Comprueba si el numero y la letra es corrrecta
     *
     * @param DNI
     * @throws DNIException
     */
    public static void validarDNI(String DNI) throws DNIException {

        //Comprobamos la longitud del dni
        if (!(DNI.length() >= 8 && DNI.length() <= 9)) {
            throw new DNIException(DNIException.LONGITUD_NO_CORRECTA);
        }

        //saco la parte numerica
        String parte_numerica = DNI.substring(0, DNI.length() - 1);

        //Aqui guardare el dni
        int numeroDNI = 0;

        try {
            //Lo transformo en un numero
            //Puede saltar la excepcion
            numeroDNI = Integer.parseInt(parte_numerica);
        } catch (NumberFormatException e) {
            throw new DNIException(DNIException.PARTE_NUMERICA_NO_CORRECTA);
        }

        //
        char letra = DNI.substring(DNI.length() - 1, DNI.length()).toUpperCase().charAt(0);

        if (!(letra >= 'A' && letra <= 'Z')) {
            throw new DNIException(DNIException.PARTE_LETRA_NO_CORRECTA);
        }

        //Ya hemos validado el formato
        final int DIVISOR = 23;

        char letrasNIF[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y',
            'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z',
            'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

        int resto = numeroDNI % DIVISOR;

        String nuevoDNI = numeroDNI + "" + letrasNIF[resto];

        if (DNI.startsWith("0")) {
            nuevoDNI = "0" + nuevoDNI;
        }

        if (!(nuevoDNI.equals(DNI))) {
            throw new DNIException(DNIException.FORMATO_NO_CORRECTO);
        }

    }

}
