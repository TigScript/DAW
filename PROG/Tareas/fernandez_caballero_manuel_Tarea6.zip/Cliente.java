/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarea6;

/**
 *
 * @author manu_
 */
import java.io.Serializable;

public class Cliente implements Serializable {
    // para que la clase sea serializable añadimos "implements Serializable"

    private static final long serialVersionUID = -1L; //para evitar problemas  de serializacion
    //La variable "serialVersionUID" se utiliza para la serialización de objetos en Java. La serialización es el proceso de convertir un objeto en una secuencia de bytes para poder almacenarlo en un archivo o transmitirlo a través de una red. El valor de "serialVersionUID" se utiliza para garantizar que dos objetos serializados tengan la misma versión y se puedan deserializar correctamente.
//En este caso, el valor -1L indica que se debe generar automáticamente un valor único para la clase. La JVM utiliza un algoritmo para generar un valor único basado en los miembros de la clase y su orden. Esto significa que si se agrega o elimina algún miembro de la clase, el valor de "serialVersionUID" también cambiará, lo que ayuda a prevenir problemas de compatibilidad.

    private String DNI;
    private String Nombre;
    private String Telefono;
    private String Direccion;
    private String Deuda; //podria haber declarado esta variable tipo double dependiendo

    public Cliente(String DNI, String Nombre, String Telefono, String Direccion, String Deuda) {
        this.DNI = DNI;
        this.Nombre = Nombre;
        this.Telefono = Telefono;
        this.Direccion = Direccion;
        this.Deuda = Deuda; 
        
    }

    //setters y getters predefinidos
    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }
     public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getDeuda() {
        return Deuda;
    }

    public void setDeuda(String Deuda) {
        this.Deuda = Deuda;
    }

    @Override
    public String toString() {
        return "Cliente{" + "DNI=" + DNI + ", Nombre=" + Nombre + ", Telefono=" + Telefono + ", Direccion=" + Direccion + ", Deuda=" + Deuda + '}';
    }
    


}