/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package practica10;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.*;




/**
 *
 * @author manu_
 */
public class Practica10 {
/*Constantes necesarias para la conexión de la base de datos */
 private static final String driver = "org.apache.derby.jdbc.EmbeddedDriver"; 
    private static final String bbdd = "jdbc:derby://localhost:1527//Users/manu_/Documentos/NetBeansProjects/Tarea10/DBTarea10";
    private static final String usuario = "APP";
    private static final String clave = "APP";
    static Scanner teclado = new Scanner(System.in);
    
    public static ArrayList<String>consultas = new ArrayList<String>();
    

    public static Connection Conexion() {
        Connection conexion = null;

        try {
            Class.forName(driver); /* para indicar driver*/

            conexion = DriverManager.getConnection(bbdd, usuario, clave);
        } catch (Exception e) {
            System.out.println("Error al conectar con la base de datos.\n" + e.getMessage().toString());
        }

        return conexion;
    }

      public static void main(String[] args) {
        int opcion = 0;
        
        do{
            System.out.println("1.Insertar termino");
            System.out.println("2.Borrar termino");
            System.out.println("3.Consultar termino");
            System.out.println("4.Mirar consultas");
            System.out.println("0.Salir");
            
            System.out.println("Introduce la opcion a realizar");
            opcion = teclado.nextInt();
            
            switch(opcion){
                case 1:
                    InsertarTermino();
                    break;
                case 2:
                    BorrarTermino();
                    break;
                case 3:
                    ConsultarTermino();
                    break;
                case 4:
                    VerConsultas();
                    break;
                default:
                   
                    break;
            }
            
        }while(opcion != 0);
    }
      
      
      
      public static void InsertarTermino() {
        Connection conexion = null;

        conexion = Conexion();

        System.out.println("Introduce el termino a insertar: ");
        String termino = teclado.next();

        Statement statement; //nueva instancia de la base de datos
        try {
            statement = conexion.createStatement(); //createStatement no modifica la abse de datos
            ResultSet resultSet = statement.executeQuery("select * from terminos where termino ='" + termino + "'");

        
            if (!resultSet.next()) {
                PreparedStatement ps; //modifica la base de datos
                ps = conexion.prepareStatement("insert into terminos(termino) values('" + termino + "')");
                ps.executeUpdate();

                System.out.println("¿Quieres introducir traducciones para este termino?");
                String respuesta = teclado.next();
                while (respuesta.equals("si")) {
                    InsertarTraducciones(termino);
                    System.out.println("¿Quieres introducir traducciones para este termino?");
                    respuesta = teclado.next();
                }
            } else {
                System.out.println("El termino ya se encuentra en la base de datos.");
            }

            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Practica10.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
      
      
       public static void InsertarTraducciones(String termino) {
        Connection conexion = null;

        conexion = Conexion(); //conexión base de datos

     
        System.out.println("Introduce la traducción a insertar: ");
        String traduccion = teclado.next();
        Statement statement;
        try {
            statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery("select idtermino from terminos where termino = '" + termino + "'");

            int id = 0;

            while (resultSet.next()) {
                id = resultSet.getInt("IDTERMINO");

            }

            statement = conexion.createStatement();
            resultSet = statement.executeQuery("select * from traducciones where traduccion = '" + traduccion + "'");

            if (!resultSet.next()) {
                PreparedStatement ps;
                ps = conexion.prepareStatement("insert into traducciones(terminoid,traduccion) values(" + id + ",'" + traduccion + "')");
                ps.executeUpdate();

            } else {
                System.out.println("La traduccion ya se encuentra en la base de datos");
            }

            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Practica10.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      
        public static void BorrarTermino() {
        Connection conexion = null;

        conexion = Conexion();

         System.out.println("Introduce el termino a borrar: ");
        String termino = teclado.next();

        PreparedStatement ps;
        try {
            
            ps = conexion.prepareStatement("delete from terminos where termino = '"+termino+"'");
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Practica10.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
       
         public static void ConsultarTermino() {

        Connection conexion = null;
        conexion = Conexion();
        Statement statement;
        Statement statement2;
        PreparedStatement ps;

        System.out.println("Introduce el termino a consultar");
        String termino = teclado.next();
        try {
            statement = conexion.createStatement();
            statement2 = conexion.createStatement();
          
            ResultSet resultSet = statement.executeQuery("select * from terminos where termino like '%" + termino + "%'");
            ResultSet resultSet2;
            int idter;
            String consultado;
            System.out.println("TERMINO\tTRADUCCIONES\t");
            while (resultSet.next()) {             
                idter = resultSet.getInt("IDTERMINO");
                consultado = resultSet.getString("TERMINO");
                System.out.print( consultado+ "\t");
                consultas.add(consultado);
                resultSet2 = statement2.executeQuery("select traduccion from traducciones where terminoid =" + idter + "");
                while (resultSet2.next()) {
                    System.out.print(resultSet2.getString("TRADUCCION") + "\t");
                }

                System.out.println("");
                
            }
    
        } catch (SQLException ex) {
            Logger.getLogger(Practica10.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
         
        public static void VerConsultas(){
       
        System.out.println("Introduce el termino a consultar");
        String termino = teclado.next();
        int contador = 0;
        for(int i = 0; i<consultas.size();i++){
           
            if(termino.equals(consultas.get(i)))
                contador++;
        }
        System.out.println(termino+" = "+contador);
    }
    }
         
