/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author manu_
 */
@Entity
@Table(name = "TRADUCCIONES")
@NamedQueries({
    @NamedQuery(name = "Traducciones.findAll", query = "SELECT t FROM Traducciones t"),
    @NamedQuery(name = "Traducciones.findByIdtraduccion", query = "SELECT t FROM Traducciones t WHERE t.idtraduccion = :idtraduccion"),
    @NamedQuery(name = "Traducciones.findByTraduccion", query = "SELECT t FROM Traducciones t WHERE t.traduccion = :traduccion")})
public class Traducciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDTRADUCCION")
    private Integer idtraduccion;
    @Basic(optional = false)
    @Column(name = "TRADUCCION")
    private String traduccion;
    @JoinColumn(name = "TERMINOID", referencedColumnName = "IDTERMINO")
    @ManyToOne(optional = false)
    private Terminos terminoid;

    public Traducciones() {
    }

    public Traducciones(Integer idtraduccion) {
        this.idtraduccion = idtraduccion;
    }

    public Traducciones(Integer idtraduccion, String traduccion) {
        this.idtraduccion = idtraduccion;
        this.traduccion = traduccion;
    }

    public Integer getIdtraduccion() {
        return idtraduccion;
    }

    public void setIdtraduccion(Integer idtraduccion) {
        this.idtraduccion = idtraduccion;
    }

    public String getTraduccion() {
        return traduccion;
    }

    public void setTraduccion(String traduccion) {
        this.traduccion = traduccion;
    }

    public Terminos getTerminoid() {
        return terminoid;
    }

    public void setTerminoid(Terminos terminoid) {
        this.terminoid = terminoid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtraduccion != null ? idtraduccion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Traducciones)) {
            return false;
        }
        Traducciones other = (Traducciones) object;
        if ((this.idtraduccion == null && other.idtraduccion != null) || (this.idtraduccion != null && !this.idtraduccion.equals(other.idtraduccion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "practica10.Traducciones[ idtraduccion=" + idtraduccion + " ]";
    }
    
}
