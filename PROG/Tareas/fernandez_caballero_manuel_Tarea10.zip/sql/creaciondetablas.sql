/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  manu_
 * Created: 26 mar 2023
 */


CREATE TABLE  terminos(

idtermino INTEGER PRIMARY KEY NOT NULL GENERATED always AS IDENTITY,
termino VARCHAR(30) NOT NULL
);

CREATE TABLE traducciones(

idtraduccion INTEGER PRIMARY KEY NOT NULL GENERATED always AS IDENTITY, /* cada vez que se inserte una fila en la tabla, se generará un valor único para esta columna.*/
terminoid INTEGER NOT NULL,
traduccion VARCHAR(30) NOT NULL,
FOREIGN KEY (terminoid) REFERENCES terminos(idtermino) ON DELETE CASCADE
);