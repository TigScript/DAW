/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author manu_
 */
@Entity
@Table(name = "TERMINOS")
@NamedQueries({
    @NamedQuery(name = "Terminos.findAll", query = "SELECT t FROM Terminos t"),
    @NamedQuery(name = "Terminos.findByIdtermino", query = "SELECT t FROM Terminos t WHERE t.idtermino = :idtermino"),
    @NamedQuery(name = "Terminos.findByTermino", query = "SELECT t FROM Terminos t WHERE t.termino = :termino")})
public class Terminos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "IDTERMINO")
    private Integer idtermino;
    @Basic(optional = false)
    @Column(name = "TERMINO")
    private String termino;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "terminoid")
    private Collection<Traducciones> traduccionesCollection;

    public Terminos() {
    }

    public Terminos(Integer idtermino) {
        this.idtermino = idtermino;
    }

    public Terminos(Integer idtermino, String termino) {
        this.idtermino = idtermino;
        this.termino = termino;
    }

    public Integer getIdtermino() {
        return idtermino;
    }

    public void setIdtermino(Integer idtermino) {
        this.idtermino = idtermino;
    }

    public String getTermino() {
        return termino;
    }

    public void setTermino(String termino) {
        this.termino = termino;
    }

    public Collection<Traducciones> getTraduccionesCollection() {
        return traduccionesCollection;
    }

    public void setTraduccionesCollection(Collection<Traducciones> traduccionesCollection) {
        this.traduccionesCollection = traduccionesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtermino != null ? idtermino.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Terminos)) {
            return false;
        }
        Terminos other = (Terminos) object;
        if ((this.idtermino == null && other.idtermino != null) || (this.idtermino != null && !this.idtermino.equals(other.idtermino))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "practica10.Terminos[ idtermino=" + idtermino + " ]";
    }
    
}
