public class Complementos {

	private float Talla;

	public float getTalla() {
		// TODO - implement Complementos.getTalla
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Talla
	 */
	public void setTalla(float Talla) {
		// TODO - implement Complementos.setTalla
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param articulo
	 * @param talla
	 */
	public Complementos(Articulos articulo, float talla) {
		// TODO - implement Complementos.Complementos
		throw new UnsupportedOperationException();
	}

	public Articulos getArticulo() {
		// TODO - implement Complementos.getArticulo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param articulo
	 */
	public void setArticulo(Articulos articulo) {
		// TODO - implement Complementos.setArticulo
		throw new UnsupportedOperationException();
	}

}