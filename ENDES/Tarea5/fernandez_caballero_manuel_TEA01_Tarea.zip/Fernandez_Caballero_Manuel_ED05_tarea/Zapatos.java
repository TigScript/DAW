public class Zapatos {

	private int Numero;
	private string Tipo;

	public int getNumero() {
		// TODO - implement Zapatos.getNumero
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Numero
	 */
	public void setNumero(int Numero) {
		// TODO - implement Zapatos.setNumero
		throw new UnsupportedOperationException();
	}

	public string getTipo() {
		// TODO - implement Zapatos.getTipo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Tipo
	 */
	public void setTipo(string Tipo) {
		// TODO - implement Zapatos.setTipo
		throw new UnsupportedOperationException();
	}

}