public class Almacen {

	private int paqueteNum;
	private string destino;

	public int getPaqueteNum() {
		return this.paqueteNum;
	}

	/**
	 * 
	 * @param paqueteNum
	 */
	public void setPaqueteNum(int paqueteNum) {
		this.paqueteNum = paqueteNum;
	}

	public string getDestino() {
		return this.destino;
	}

	/**
	 * 
	 * @param destino
	 */
	public void setDestino(string destino) {
		this.destino = destino;
	}

	/**
	 * 
	 * @param direSocio
	 */
	public string asignarDestino(string direSocio) {
		// TODO - implement Almacen.asignarDestino
		throw new UnsupportedOperationException();
	}

}