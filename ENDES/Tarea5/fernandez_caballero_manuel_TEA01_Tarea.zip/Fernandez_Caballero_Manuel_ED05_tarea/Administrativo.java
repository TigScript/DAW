public class Administrativo {

	private string nombre;

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void compruebaPedidoPendiente(date fecha) {
		// TODO - implement Administrativo.compruebaPedidoPendiente
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param temporada
	 */
	public boolean altaNuevaCampana(string temporada) {
		// TODO - implement Administrativo.altaNuevaCampana
		throw new UnsupportedOperationException();
	}

}