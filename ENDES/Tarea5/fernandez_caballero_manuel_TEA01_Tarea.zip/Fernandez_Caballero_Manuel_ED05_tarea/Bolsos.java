public class Bolsos {

	private string Tipo;

	public string getTipo() {
		// TODO - implement Bolsos.getTipo
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Tipo
	 */
	public void setTipo(string Tipo) {
		// TODO - implement Bolsos.setTipo
		throw new UnsupportedOperationException();
	}

}