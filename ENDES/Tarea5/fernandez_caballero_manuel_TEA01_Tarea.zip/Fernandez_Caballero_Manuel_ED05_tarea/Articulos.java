public class Articulos {

	private string Nombre;
	private string Temporada;
	private string Descripcion;
	private string Material;
	private string Color;
	private float precio;
	private int stock;

	public string getNombre() {
		// TODO - implement Articulos.getNombre
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Nombre
	 */
	public void setNombre(string Nombre) {
		// TODO - implement Articulos.setNombre
		throw new UnsupportedOperationException();
	}

	public string getTemporada() {
		// TODO - implement Articulos.getTemporada
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Temporada
	 */
	public void setTemporada(string Temporada) {
		// TODO - implement Articulos.setTemporada
		throw new UnsupportedOperationException();
	}

	public string getDescripcion() {
		// TODO - implement Articulos.getDescripcion
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Descripcion
	 */
	public void setDescripcion(string Descripcion) {
		// TODO - implement Articulos.setDescripcion
		throw new UnsupportedOperationException();
	}

	public string getMaterial() {
		// TODO - implement Articulos.getMaterial
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Material
	 */
	public void setMaterial(string Material) {
		// TODO - implement Articulos.setMaterial
		throw new UnsupportedOperationException();
	}

	public string getColor() {
		// TODO - implement Articulos.getColor
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Color
	 */
	public void setColor(string Color) {
		// TODO - implement Articulos.setColor
		throw new UnsupportedOperationException();
	}

	public float getPrecio() {
		return this.precio;
	}

	/**
	 * 
	 * @param precio
	 */
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public int getStock() {
		return this.stock;
	}

	/**
	 * 
	 * @param stock
	 */
	public void setStock(int stock) {
		this.stock = stock;
	}

}