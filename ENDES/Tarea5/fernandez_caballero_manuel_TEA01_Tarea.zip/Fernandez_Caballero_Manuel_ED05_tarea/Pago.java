public class Pago {

	private string tarjeta;
	private date fecha;
	private Socio socio;

	public string getTarjeta() {
		return this.tarjeta;
	}

	/**
	 * 
	 * @param tarjeta
	 */
	public void setTarjeta(string tarjeta) {
		this.tarjeta = tarjeta;
	}

	public date getFecha() {
		return this.fecha;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFecha(date fecha) {
		this.fecha = fecha;
	}

	public Socio getSocio() {
		return this.socio;
	}

	/**
	 * 
	 * @param socio
	 */
	public void setSocio(Socio socio) {
		this.socio = socio;
	}

	/**
	 * 
	 * @param numero
	 */
	public void comprobarTarjeta(long numero) {
		// TODO - implement Pago.comprobarTarjeta
		throw new UnsupportedOperationException();
	}

}