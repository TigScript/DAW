public class Ruta {

	private string areaInfluencia;
	private string diasReparto;
	private date fecha;

	public string getAreaInfluencia() {
		return this.areaInfluencia;
	}

	/**
	 * 
	 * @param areaInfluencia
	 */
	public void setAreaInfluencia(string areaInfluencia) {
		this.areaInfluencia = areaInfluencia;
	}

	/**
	 * 
	 * @param diasReparto
	 */
	public void setDiasReparto(string diasReparto) {
		this.diasReparto = diasReparto;
	}

	public string getDiasReparto() {
		return this.diasReparto;
	}

	public date getFecha() {
		return this.fecha;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFecha(date fecha) {
		this.fecha = fecha;
	}

	/**
	 * 
	 * @param direSocio
	 */
	public string destino(string direSocio) {
		// TODO - implement Ruta.destino
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fecha
	 */
	public int diaReparto(date fecha) {
		// TODO - implement Ruta.diaReparto
		throw new UnsupportedOperationException();
	}

}