public class Campa�a {

	private string temporada;

	public string getTemporada() {
		return this.temporada;
	}

	/**
	 * 
	 * @param temporada
	 */
	public void setTemporada(string temporada) {
		this.temporada = temporada;
	}

}