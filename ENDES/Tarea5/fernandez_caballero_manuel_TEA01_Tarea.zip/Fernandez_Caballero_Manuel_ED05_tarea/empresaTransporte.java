public class empresaTransporte {

	private string nombre;
	private string CIF;
	private string domicilioFiscal;

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public string getCIF() {
		// TODO - implement empresaTransporte.getCIF
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param CIF
	 */
	public void setCIF(string CIF) {
		// TODO - implement empresaTransporte.setCIF
		throw new UnsupportedOperationException();
	}

	public string getDomicilioFiscal() {
		return this.domicilioFiscal;
	}

	/**
	 * 
	 * @param domicilioFiscal
	 */
	public void setDomicilioFiscal(string domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}

}