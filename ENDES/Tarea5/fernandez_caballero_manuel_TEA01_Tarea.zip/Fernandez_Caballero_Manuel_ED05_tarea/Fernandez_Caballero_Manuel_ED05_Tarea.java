/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fernandez_caballero_manuel_ed05_tarea;

/**
 *
 * @author manu_
 */
public class Fernandez_Caballero_Manuel_ED05_Tarea {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
