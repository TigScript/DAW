public class Firma {

	private string nombre;
	private string cif;
	private string domicilioFiscal;

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public string getCif() {
		return this.cif;
	}

	/**
	 * 
	 * @param cif
	 */
	public void setCif(string cif) {
		this.cif = cif;
	}

	public string getDomicilioFiscal() {
		return this.domicilioFiscal;
	}

	/**
	 * 
	 * @param domicilioFiscal
	 */
	public void setDomicilioFiscal(string domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}

}