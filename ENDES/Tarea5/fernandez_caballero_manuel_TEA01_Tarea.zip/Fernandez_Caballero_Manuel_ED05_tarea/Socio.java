public class Socio {

	private string nombre;
	private string correoElectronico;
	private string direccion;

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public string getCorreoElectronico() {
		return this.correoElectronico;
	}

	/**
	 * 
	 * @param correoElectronico
	 */
	public void setCorreoElectronico(string correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public string getDireccion() {
		return this.direccion;
	}

	/**
	 * 
	 * @param direccion
	 */
	public void setDireccion(string direccion) {
		this.direccion = direccion;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void verPedido(date fecha) {
		// TODO - implement Socio.verPedido
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fecha
	 */
	public boolean cancelarPedido(date fecha) {
		// TODO - implement Socio.cancelarPedido
		throw new UnsupportedOperationException();
	}

}