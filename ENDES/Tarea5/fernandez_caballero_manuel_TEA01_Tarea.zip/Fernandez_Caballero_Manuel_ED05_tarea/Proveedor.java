public class Proveedor {

	private string nombre;
	private string CIF;
	private string comicilioFiscal;

	public string getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(string nombre) {
		this.nombre = nombre;
	}

	public string getCIF() {
		// TODO - implement Proveedor.getCIF
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param CIF
	 */
	public void setCIF(string CIF) {
		// TODO - implement Proveedor.setCIF
		throw new UnsupportedOperationException();
	}

	public string getComicilioFiscal() {
		return this.comicilioFiscal;
	}

	/**
	 * 
	 * @param comicilioFiscal
	 */
	public void setComicilioFiscal(string comicilioFiscal) {
		this.comicilioFiscal = comicilioFiscal;
	}

}